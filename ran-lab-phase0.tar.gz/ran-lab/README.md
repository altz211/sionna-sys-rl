# RAN-LAB

**A reproducible system-level testbed for learned radio resource management in multi-cell 5G/6G networks.**

[![CI](https://github.com/altz211/ran-lab/actions/workflows/ci.yml/badge.svg)](https://github.com/altz211/ran-lab/actions/workflows/ci.yml)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

---

## The question

Does a learned resource-management policy improve **cell-edge** and aggregate
network performance over standardised classical baselines — and does it do so
under conditions where the comparison is actually fair?

Most published claims of learned-scheduler gains are hard to check. The
baseline is under-specified, the policy sees information the baseline does
not, results come from one random seed, and the code does not run. RAN-LAB is
built to make the opposite easy: every policy observes an identical state,
every KPI is a mean over independent seeds with a confidence interval, and
every figure regenerates from a clean clone with one command.

> ### ⚠️ Current status: Phase 0 — harness complete, physics is a placeholder
>
> The experiment infrastructure is finished and tested (126 tests). The
> channel and PHY models are deliberate placeholders so the pipeline could be
> built and validated end to end first. **No number this repository currently
> produces is a result.** Figures demonstrate that the machinery works; they
> say nothing about radio networks. The generated report states this on its
> face. See [`docs/limitations.md`](docs/limitations.md) and the roadmap below.

---

## Quick start

```bash
git clone https://github.com/altz211/ran-lab.git && cd ran-lab
make setup                      # virtualenv + editable install
make sweep EXPERIMENT=scheduler_comparison WORKERS=4
make report                     # -> results/processed/report.html
```

Or without installing anything:

```bash
docker compose run --rm sweep
docker compose run --rm report
```

Reproduce every artefact from scratch:

```bash
make reproduce EXPERIMENT=scheduler_comparison
```

---

## What it does

```
deployment ─> large-scale channel ─> per-slot SINR ─> PHY abstraction
           ─> per-cell scheduling ─> KPI accumulation ─> Parquet + report
```

- **3GPP-shaped deployment** — hexagonal sites, three sectors, TR 38.901
  antenna pattern, toroidal wrap-around so edge cells are not optimistically
  biased.
- **Three classical baselines** — Round Robin, Proportional Fair, Max C/I,
  bracketing the throughput/fairness region a learned policy must improve on.
- **Realistic CSI** — policies act on a *delayed, periodically reported* rate
  estimate; delivery uses the true channel. Handing a scheduler the
  instantaneous channel is the commonest way a study reports an unachievable
  gain.
- **Declarative experiments** — sweeps are YAML, not scripts.
- **Provenance on every row** — code revision, working-tree cleanliness,
  condition hash, seed and library versions.
- **Statistics by default** — bootstrap confidence intervals, seed-paired
  tests and Cohen's *d*, not a difference of two means.

### Example

```bash
ranlab run scheduler=proportional_fair scenario.n_ue_per_cell=20
ranlab sweep experiment=sweep_density run=multiseed --workers 8
ranlab config scheduler=max_ci            # resolve and print, run nothing
```

---

## Figures

Regenerate with `make report`. *(Phase-0 placeholder physics — plumbing
evidence only.)*

| | |
|---|---|
| ![Throughput CDF](results/figures/throughput_cdf.png) | ![Fairness trade-off](results/figures/fairness_tradeoff.png) |
| **Per-UE throughput CDF**, 5th-percentile cell-edge point marked. The whole distribution, because a mean cannot distinguish "everyone improved" from "the median improved while the tail collapsed". | **Throughput / fairness trade-off.** The classical policies bracket the region. Up-and-right dominates; up-and-left has only traded fairness for throughput. |

---

## Design decisions worth stating

**Every policy observes an identical state.** Classical and learned policies
implement one interface (`ranlab.mac.base`) and receive the same `SlotState`.
If the learned policy could see anything extra, any gain it showed would be
uninterpretable. A Phase-4 validation gate enforces this: a policy frozen to
imitate PF must match PF within seed noise.

**The condition hash excludes the seed.** It identifies the *experimental
condition*, so N seeds of one condition group together automatically and
confidence intervals need no bookkeeping by hand.

**The result schema is declared, not inferred.** Arrow schemas are pinned in
`ranlab/io/results.py`. An inferred schema drifts silently — an all-null
column in one run refuses to concatenate with the next. Pinning turns that
into an immediate, loud failure.

**Determinism does not depend on worker count.** Sweep seeds derive from
position in the expansion, never from a shared generator. Serial and parallel
runs are asserted bit-identical.

**Validation gates are written before the code they validate.** They currently
skip with a reason naming their phase, so the acceptance criteria live in the
repository rather than in somebody's memory. See
[`docs/validation.md`](docs/validation.md).

**Configuration is typed and frozen.** Pydantic models with
`extra="forbid"`, so a YAML typo raises instead of being silently ignored —
the classic source of irreproducible results. Hydra-style composition
(`group=option`, `dotted.key=value`) is implemented directly on PyYAML, which
keeps the harness's dependency footprint small enough for CI to install and
run in seconds, and makes the composition logic itself unit-testable.

---

## Repository layout

```
configs/          experiment configuration — every parameter the model uses
  scenario/       deployment geometry            channel/   propagation
  scheduler/      resource-management policies   traffic/   demand models
  phy/ power/     link abstraction, energy       experiment/ declared sweeps
src/ranlab/
  config/         typed schema + composition + condition hashing
  scenario/       hex layout, UE dropping, serving-cell assignment
  channel/        propagation            phy/     link-to-system abstraction
  mac/            scheduler ABC + baselines
  metrics/        KPIs + bootstrap CIs + effect sizes
  sweep/          expansion and parallel execution
  io/             provenance capture + pinned Parquet schema
  viz/            figures + self-contained HTML report
docs/             methodology, validation gates, experiment log, limitations
tests/            unit / integration / validation
```

---

## Documentation

| | |
|---|---|
| [`docs/methodology.md`](docs/methodology.md) | The system model, with standards clauses for every parameter |
| [`docs/validation.md`](docs/validation.md) | Gates that must pass before results may be quoted |
| [`docs/limitations.md`](docs/limitations.md) | What is not modelled, and what that means |
| [`docs/experiments.md`](docs/experiments.md) | Append-only log of questions asked and answered |

---

## Roadmap

| Phase | Deliverable | Status |
|---|---|---|
| **0** | Experiment harness, result schema, provenance, sweeps, reporting, CI | ✅ complete |
| **1** | TR 38.901 UMi/UMa channel, EESM abstraction · gates V1–V4 | ⬜ next |
| **2** | Multi-cell interference, FTP Model 3, mobility · gates V5–V8 | ⬜ |
| **3** | Full sweeps, confidence intervals, publication figure set | ⬜ |
| **4** | Learned policy (Gymnasium + PPO), benchmarked against PF · gate V9 | ⬜ |
| **5** | Real base-station topology from OpenCelliD | ⬜ |
| **6** | LLM experiment-analyst module | ⬜ |

Phase 3 is deliberately placed before the learned policy: at that point the
repository is a complete, publishable simulation study **even if the ML never
works**. That ordering is a hedge against the most likely failure mode.

---

## Development

```bash
make check        # lint + typecheck + tests, exactly what CI runs
make test         # pytest with coverage
pytest -m "not slow" -q
pytest -m validation -v
```

## Citing

See [`CITATION.cff`](CITATION.cff), or use GitHub's "Cite this repository".

## License

MIT — see [`LICENSE`](LICENSE).
