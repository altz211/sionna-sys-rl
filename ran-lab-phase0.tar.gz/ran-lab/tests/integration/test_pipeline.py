"""End-to-end pipeline tests.

These are the tests that protect the property the whole repository is built
around: that a result can be reproduced exactly, including under parallel
execution and across process boundaries.
"""

from __future__ import annotations

import numpy as np
import pytest

from ranlab.config import compose, condition_hash
from ranlab.engine import simulate
from ranlab.io import capture_provenance, load_results, write_run_results
from ranlab.sweep import expand_sweep, run_sweep

FAST = ["sim=quick", "scenario.n_rings=0", "scenario.sectors_per_site=3",
        "scenario.n_ue_per_cell=3"]


class TestSingleRun:
    def test_produces_well_formed_output(self, base_config):
        output = simulate(base_config, seed=1)
        expected_ue = base_config.scenario.n_cells * base_config.scenario.n_ue_per_cell
        assert len(output.ue_rows) == expected_ue
        assert output.runtime_s > 0

    def test_kpis_are_physically_plausible(self, base_config):
        row = simulate(base_config, seed=1).run_row
        assert row["mean_ue_throughput_bps"] >= 0
        assert row["p5_ue_throughput_bps"] <= row["p50_ue_throughput_bps"]
        assert row["p50_ue_throughput_bps"] <= row["p95_ue_throughput_bps"]
        assert 0.0 <= row["jain_fairness"] <= 1.0
        assert row["total_energy_j"] > 0

    def test_is_deterministic_given_a_seed(self, base_config):
        a = simulate(base_config, seed=99)
        b = simulate(base_config, seed=99)
        np.testing.assert_array_equal(
            a.ue_rows["throughput_bps"].to_numpy(),
            b.ue_rows["throughput_bps"].to_numpy(),
        )

    def test_different_seeds_give_different_results(self, base_config):
        a = simulate(base_config, seed=1)
        b = simulate(base_config, seed=2)
        assert not np.allclose(
            a.ue_rows["throughput_bps"].to_numpy(),
            b.ue_rows["throughput_bps"].to_numpy(),
        )

    def test_no_throughput_is_attributed_to_warmup(self, config_dir):
        """Warm-up slots must drive state without contributing to KPIs."""
        config = compose(config_dir, overrides=[*FAST, "sim.n_slots=20", "sim.warmup_slots=0"])
        warm = compose(config_dir, overrides=[*FAST, "sim.n_slots=20", "sim.warmup_slots=30"])
        assert simulate(config, seed=5).run_row["n_slots"] == 20
        assert simulate(warm, seed=5).run_row["warmup_slots"] == 30


class TestSchedulerOrdering:
    """The Phase-2 validation gate, asserted on the Phase-0 placeholder physics.

    The absolute numbers are not meaningful yet, but the *ordering* is a
    property of the policies rather than of the channel, so it must already
    hold. If it ever stops holding, either a policy or the engine is broken.
    """

    @pytest.mark.slow
    def test_throughput_ordering(self, config_dir):
        means = {}
        for algorithm in ("round_robin", "proportional_fair", "max_ci"):
            config = compose(
                config_dir,
                overrides=[f"scheduler={algorithm}", "sim=quick", "scenario.n_ue_per_cell=5"],
            )
            means[algorithm] = np.mean(
                [simulate(config, seed=s).run_row["cell_throughput_bps"] for s in range(4)]
            )
        assert means["max_ci"] > means["proportional_fair"] > means["round_robin"]

    @pytest.mark.slow
    def test_max_ci_is_least_fair(self, config_dir):
        fairness = {}
        for algorithm in ("round_robin", "proportional_fair", "max_ci"):
            config = compose(
                config_dir,
                overrides=[f"scheduler={algorithm}", "sim=quick", "scenario.n_ue_per_cell=5"],
            )
            fairness[algorithm] = np.mean(
                [simulate(config, seed=s).run_row["jain_fairness"] for s in range(4)]
            )
        assert fairness["max_ci"] < fairness["round_robin"]
        assert fairness["max_ci"] < fairness["proportional_fair"]


class TestSweepExpansion:
    def test_single_experiment_yields_one_point(self, config_dir):
        config = compose(config_dir, overrides=FAST)
        assert len(expand_sweep(config)) == 1

    def test_cartesian_product_across_axes(self, config_dir):
        config = compose(config_dir, overrides=["experiment=sweep_density"])
        # 3 schedulers x 4 densities x 1 seed
        assert len(expand_sweep(config)) == 12

    def test_seeds_multiply_the_expansion(self, config_dir):
        config = compose(
            config_dir, overrides=["experiment=scheduler_comparison", "run.n_seeds=5"]
        )
        assert len(expand_sweep(config)) == 15

    def test_points_are_uniquely_identified(self, config_dir):
        config = compose(
            config_dir, overrides=["experiment=sweep_density", "run.n_seeds=3"]
        )
        points = expand_sweep(config)
        assert len({(p.overrides, p.seed) for p in points}) == len(points)


class TestSweepExecution:
    def test_writes_one_result_set_per_point(self, config_dir, tmp_path):
        config = compose(
            config_dir,
            overrides=["experiment=scheduler_comparison", *FAST, "run.n_seeds=2"],
        )
        records = run_sweep(
            config,
            config_dir=str(config_dir),
            base_overrides=["experiment=scheduler_comparison", *FAST, "run.n_seeds=2"],
            output_dir=tmp_path,
            n_workers=1,
        )
        assert len(records) == 6
        assert len(load_results(tmp_path, level="run")) == 6

    def test_conditions_and_seeds_group_correctly(self, config_dir, tmp_path):
        overrides = ["experiment=scheduler_comparison", *FAST, "run.n_seeds=3"]
        config = compose(config_dir, overrides=overrides)
        run_sweep(config, config_dir=str(config_dir), base_overrides=overrides,
                  output_dir=tmp_path, n_workers=1)
        df = load_results(tmp_path, level="run")
        assert df["condition_hash"].nunique() == 3   # three policies
        assert df["seed"].nunique() == 3             # three seeds each
        assert df.groupby("condition_hash").size().eq(3).all()

    @pytest.mark.slow
    def test_parallel_execution_matches_serial(self, config_dir, tmp_path):
        """Reproducibility must not depend on the worker count."""
        overrides = ["experiment=scheduler_comparison", *FAST, "run.n_seeds=2"]
        config = compose(config_dir, overrides=overrides)

        serial_dir, parallel_dir = tmp_path / "serial", tmp_path / "parallel"
        for out_dir, workers in ((serial_dir, 1), (parallel_dir, 3)):
            run_sweep(config, config_dir=str(config_dir), base_overrides=overrides,
                      output_dir=out_dir, n_workers=workers)

        key = ["scheduler", "seed"]
        serial = load_results(serial_dir, level="run").sort_values(key).reset_index(drop=True)
        parallel = load_results(parallel_dir, level="run").sort_values(key).reset_index(drop=True)

        np.testing.assert_allclose(
            serial["mean_ue_throughput_bps"].to_numpy(),
            parallel["mean_ue_throughput_bps"].to_numpy(),
            rtol=0, atol=0,
        )


class TestReportPipeline:
    def test_builds_figures_and_html(self, config_dir, tmp_path, base_config):
        from ranlab.metrics import aggregate_over_seeds
        from ranlab.viz import build_report, save_all_figures

        for seed in range(2):
            output = simulate(base_config, seed=seed)
            write_run_results(
                tmp_path, base_config,
                capture_provenance(condition_hash(base_config), seed, "pipeline_test"),
                output.ue_rows, output.run_row,
            )

        run_df = load_results(tmp_path, level="run")
        ue_df = load_results(tmp_path, level="ue")

        figures = save_all_figures(ue_df, run_df, tmp_path / "figures")
        assert len(figures) == 3
        assert all(p.is_file() and p.stat().st_size > 0 for p in figures)

        aggregated = aggregate_over_seeds(run_df, metrics=["mean_ue_throughput_bps"])
        report = build_report(run_df, aggregated, figures, tmp_path / "report.html")

        html = report.read_text(encoding="utf-8")
        assert "<html" in html
        assert "data:image/png;base64," in html  # figures are embedded, not linked

    def test_report_warns_about_placeholder_physics(self, base_config):
        """A Phase-0 result must never be presentable as a calibrated one."""
        assert base_config.channel.model == "stub"
        assert base_config.phy.abstraction == "stub"
