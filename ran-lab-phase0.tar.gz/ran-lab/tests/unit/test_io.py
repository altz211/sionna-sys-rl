"""Tests for provenance capture and the Parquet result schema."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from ranlab.io import (
    RUN_SCHEMA,
    UE_SCHEMA,
    ResultSchemaError,
    capture_provenance,
    condition_columns,
    environment_info,
    git_info,
    load_results,
    read_meta,
    write_run_results,
)


@pytest.fixture
def provenance():
    return capture_provenance(condition_hash="abc123def456", seed=7, experiment="unit_test")


@pytest.fixture
def ue_rows() -> pd.DataFrame:
    n = 12
    rng = np.random.default_rng(0)
    return pd.DataFrame(
        {
            "ue_id": np.arange(n, dtype=np.int32),
            "serving_cell_id": np.zeros(n, dtype=np.int32),
            "x_m": rng.normal(size=n).astype(np.float32),
            "y_m": rng.normal(size=n).astype(np.float32),
            "distance_to_serving_m": rng.uniform(10, 200, n).astype(np.float32),
            "is_los": np.zeros(n, dtype=bool),
            "mean_sinr_db": rng.normal(10, 5, n).astype(np.float32),
            "p10_sinr_db": rng.normal(5, 5, n).astype(np.float32),
            "mean_wideband_sinr_db": rng.normal(10, 5, n).astype(np.float32),
            "throughput_bps": rng.uniform(1e6, 2e7, n),
            "spectral_efficiency_bps_hz": rng.uniform(0.1, 3, n).astype(np.float32),
            "bler": np.full(n, 0.1, dtype=np.float32),
            "mean_latency_ms": np.full(n, np.nan, dtype=np.float32),
            "p95_latency_ms": np.full(n, np.nan, dtype=np.float32),
            "served_bits": rng.uniform(1e6, 1e8, n),
            "n_scheduled_slots": rng.integers(0, 100, n).astype(np.int32),
            "prb_share": rng.uniform(0, 1, n).astype(np.float32),
        }
    )


@pytest.fixture
def run_row() -> dict:
    return {
        "n_ue": 12, "n_slots": 100, "warmup_slots": 10,
        "mean_ue_throughput_bps": 1.0e7, "p5_ue_throughput_bps": 1.0e6,
        "p50_ue_throughput_bps": 9.0e6, "p95_ue_throughput_bps": 1.9e7,
        "cell_throughput_bps": 1.2e8, "spectral_efficiency_bps_hz": 6.0,
        "jain_fairness": 0.7, "mean_bler": 0.1,
        "mean_latency_ms": float("nan"), "p95_latency_ms": float("nan"),
        "energy_per_bit_nj": 12.5, "total_energy_j": 150.0, "sim_runtime_s": 0.4,
    }


class TestProvenance:
    def test_records_identity_and_environment(self, provenance):
        assert len(provenance.run_id) == 16
        assert provenance.condition_hash == "abc123def456"
        assert provenance.seed == 7
        assert provenance.python_version
        assert provenance.platform

    def test_run_ids_are_unique(self):
        ids = {capture_provenance("h", 0).run_id for _ in range(50)}
        assert len(ids) == 50

    def test_tracks_numerical_library_versions(self):
        packages = environment_info()["packages"]
        assert "numpy" in packages and "pandas" in packages

    def test_git_info_has_the_expected_keys(self):
        info = git_info()
        assert set(info) == {"git_commit", "git_branch", "git_dirty"}

    def test_flags_an_unattributable_run(self, tmp_path):
        """Outside a checkout, the record must say so rather than stay silent."""
        prov = capture_provenance("h", 0, repo_root=tmp_path)
        assert prov.git_commit is None
        assert prov.is_reproducible is False
        assert any("git revision" in w for w in prov.warnings())

    def test_column_subset_is_flat_and_serialisable(self, provenance):
        columns = provenance.to_columns()
        assert set(columns) <= set(UE_SCHEMA.names)
        json.dumps(columns)


class TestConditionColumns:
    def test_matches_the_declared_schema(self, base_config):
        columns = condition_columns(base_config)
        for name in columns:
            assert name in UE_SCHEMA.names
            assert name in RUN_SCHEMA.names

    def test_captures_the_sweep_axes(self, base_config):
        columns = condition_columns(base_config)
        for axis in ("scheduler", "n_ue_per_cell", "ue_speed_kmph", "offered_load_scale"):
            assert axis in columns


class TestWriting:
    def test_writes_all_three_artefacts(
        self, tmp_path, base_config, provenance, ue_rows, run_row
    ):
        paths = write_run_results(tmp_path, base_config, provenance, ue_rows, run_row)
        assert set(paths) == {"ue", "run", "meta"}
        assert all(p.is_file() for p in paths.values())

    def test_stamps_provenance_onto_every_row(
        self, tmp_path, base_config, provenance, ue_rows, run_row
    ):
        write_run_results(tmp_path, base_config, provenance, ue_rows, run_row)
        df = load_results(tmp_path, level="ue")
        assert (df["run_id"] == provenance.run_id).all()
        assert (df["seed"] == provenance.seed).all()
        assert (df["condition_hash"] == provenance.condition_hash).all()

    def test_sidecar_holds_the_full_config(
        self, tmp_path, base_config, provenance, ue_rows, run_row
    ):
        write_run_results(tmp_path, base_config, provenance, ue_rows, run_row)
        meta = read_meta(tmp_path, provenance.run_id)
        assert meta["config"]["scheduler"]["algorithm"] == base_config.scheduler.algorithm
        assert meta["provenance"]["run_id"] == provenance.run_id

    def test_rejects_an_empty_table(self, tmp_path, base_config, provenance, run_row):
        with pytest.raises(ResultSchemaError, match="empty"):
            write_run_results(tmp_path, base_config, provenance, pd.DataFrame(), run_row)

    def test_rejects_a_missing_column(
        self, tmp_path, base_config, provenance, ue_rows, run_row
    ):
        with pytest.raises(ResultSchemaError, match="missing required columns"):
            write_run_results(
                tmp_path, base_config, provenance, ue_rows.drop(columns=["throughput_bps"]), run_row
            )

    def test_rejects_an_undeclared_column(
        self, tmp_path, base_config, provenance, ue_rows, run_row
    ):
        """Silent schema drift is the bug this check exists to prevent."""
        rogue = ue_rows.assign(my_new_metric=1.0)
        with pytest.raises(ResultSchemaError, match="undeclared columns"):
            write_run_results(tmp_path, base_config, provenance, rogue, run_row)


class TestReading:
    def test_concatenates_multiple_runs(
        self, tmp_path, base_config, ue_rows, run_row
    ):
        for seed in range(3):
            write_run_results(
                tmp_path, base_config,
                capture_provenance("cond", seed, experiment="unit_test"),
                ue_rows, run_row,
            )
        assert len(load_results(tmp_path, level="run")) == 3
        assert len(load_results(tmp_path, level="ue")) == 3 * len(ue_rows)

    def test_empty_directory_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError, match="no \\*.run.parquet"):
            load_results(tmp_path, level="run")

    def test_invalid_level_raises(self, tmp_path):
        with pytest.raises(ValueError, match="must be"):
            load_results(tmp_path, level="nonsense")

    def test_missing_sidecar_raises(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            read_meta(tmp_path, "deadbeef")
