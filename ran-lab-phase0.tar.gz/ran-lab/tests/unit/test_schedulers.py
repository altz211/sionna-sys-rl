"""Tests for the scheduling policies.

These test policy *logic* in isolation, with the channel replaced by fixed
arrays.  That separation matters: a scheduler bug and a channel bug produce
similar-looking KPI anomalies, and only isolated tests tell them apart.
"""

from __future__ import annotations

import numpy as np
import pytest

from ranlab.mac import SchedulerContext, SlotState, build_scheduler


@pytest.fixture
def context() -> SchedulerContext:
    return SchedulerContext(n_ue=4, n_prb=51, slot_duration_s=0.5e-3, bandwidth_hz=20e6)


def make_state(
    rates: list[float],
    averages: list[float] | None = None,
    has_data: list[bool] | None = None,
    slot: int = 0,
) -> SlotState:
    n = len(rates)
    return SlotState(
        slot=slot,
        achievable_rate_bps=np.array(rates, dtype=float),
        avg_throughput_bps=np.array(averages if averages else [1.0] * n, dtype=float),
        has_data=np.array(has_data if has_data else [True] * n, dtype=bool),
    )


class TestInterfaceContract:
    """Every policy must satisfy these, or comparisons between them are invalid."""

    @pytest.mark.parametrize(
        "algorithm", ["round_robin", "proportional_fair", "max_ci"]
    )
    def test_allocation_is_a_valid_simplex_point(self, algorithm, context, rng):
        scheduler = build_scheduler(algorithm, context, rng)
        for slot in range(20):
            state = make_state(list(rng.uniform(1e6, 50e6, size=4)), slot=slot)
            allocation = scheduler.allocate(state)
            assert allocation.shape == (context.n_ue,)
            assert np.all(allocation >= 0.0)
            assert np.sum(allocation) <= 1.0 + 1e-9

    @pytest.mark.parametrize(
        "algorithm", ["round_robin", "proportional_fair", "max_ci"]
    )
    def test_never_serves_a_ue_without_data(self, algorithm, context, rng):
        scheduler = build_scheduler(algorithm, context, rng)
        has_data = [False, True, False, False]
        for slot in range(10):
            state = make_state([10e6] * 4, has_data=has_data, slot=slot)
            allocation = scheduler.allocate(state)
            assert allocation[0] == 0.0
            assert allocation[2] == 0.0
            assert allocation[3] == 0.0

    @pytest.mark.parametrize(
        "algorithm", ["round_robin", "proportional_fair", "max_ci"]
    )
    def test_idles_when_nothing_is_backlogged(self, algorithm, context, rng):
        scheduler = build_scheduler(algorithm, context, rng)
        state = make_state([10e6] * 4, has_data=[False] * 4)
        assert np.sum(scheduler.allocate(state)) == 0.0

    def test_unknown_algorithm_raises(self, context, rng):
        with pytest.raises(KeyError, match="unknown scheduler"):
            build_scheduler("telepathy", context, rng)


class TestRoundRobin:
    def test_cycles_through_all_ues(self, context, rng):
        scheduler = build_scheduler("round_robin", context, rng)
        served = [
            int(np.argmax(scheduler.allocate(make_state([10e6] * 4, slot=s))))
            for s in range(4)
        ]
        assert sorted(served) == [0, 1, 2, 3]

    def test_ignores_channel_quality(self, context, rng):
        """The defining property: allocation must not depend on the rates."""
        scheduler_a = build_scheduler("round_robin", context, np.random.default_rng(0))
        scheduler_b = build_scheduler("round_robin", context, np.random.default_rng(0))
        for slot in range(8):
            a = scheduler_a.allocate(make_state([1e6, 2e6, 3e6, 4e6], slot=slot))
            b = scheduler_b.allocate(make_state([9e6, 9e6, 9e6, 9e6], slot=slot))
            np.testing.assert_array_equal(a, b)

    def test_gives_equal_airtime(self, context, rng):
        scheduler = build_scheduler("round_robin", context, rng)
        counts = np.zeros(4)
        for slot in range(400):
            counts += scheduler.allocate(
                make_state(list(rng.uniform(1e6, 50e6, size=4)), slot=slot)
            )
        assert np.all(counts == 100)

    def test_skips_ues_without_data(self, context, rng):
        scheduler = build_scheduler("round_robin", context, rng)
        served = {
            int(np.argmax(scheduler.allocate(
                make_state([10e6] * 4, has_data=[True, False, True, False], slot=s)
            )))
            for s in range(6)
        }
        assert served == {0, 2}

    def test_reset_restores_the_pointer(self, context, rng):
        scheduler = build_scheduler("round_robin", context, rng)
        first = scheduler.allocate(make_state([10e6] * 4))
        scheduler.reset()
        np.testing.assert_array_equal(scheduler.allocate(make_state([10e6] * 4)), first)


class TestMaxCI:
    def test_serves_the_best_channel(self, context, rng):
        scheduler = build_scheduler("max_ci", context, rng)
        allocation = scheduler.allocate(make_state([1e6, 50e6, 3e6, 4e6]))
        assert int(np.argmax(allocation)) == 1

    def test_starves_a_persistently_weak_ue(self, context, rng):
        scheduler = build_scheduler("max_ci", context, rng)
        total = np.zeros(4)
        for slot in range(200):
            rates = list(rng.uniform(20e6, 30e6, size=4))
            rates[3] = 1e6  # permanently weak
            total += scheduler.allocate(make_state(rates, slot=slot))
        assert total[3] == 0.0

    def test_breaks_ties_without_index_bias(self, context):
        """Deterministic argmax would always pick UE 0 and skew fairness."""
        scheduler = build_scheduler("max_ci", context, np.random.default_rng(7))
        counts = np.zeros(4)
        for _ in range(400):
            counts += scheduler.allocate(make_state([10e6] * 4))
        assert counts.min() > 0, "tie-breaking is biased towards low-indexed UEs"


class TestProportionalFair:
    def test_prefers_a_starved_ue_at_equal_rate(self, context, rng):
        scheduler = build_scheduler("proportional_fair", context, rng)
        allocation = scheduler.allocate(
            make_state([10e6] * 4, averages=[10e6, 10e6, 1e3, 10e6])
        )
        assert int(np.argmax(allocation)) == 2

    def test_prefers_a_better_channel_at_equal_history(self, context, rng):
        scheduler = build_scheduler("proportional_fair", context, rng)
        allocation = scheduler.allocate(
            make_state([1e6, 2e6, 30e6, 4e6], averages=[5e6] * 4)
        )
        assert int(np.argmax(allocation)) == 2

    def test_uses_the_relative_not_absolute_rate(self, context, rng):
        """PF's defining property: a UE with a poor absolute channel still wins
        if its current rate is high relative to its own history."""
        scheduler = build_scheduler("proportional_fair", context, rng)
        allocation = scheduler.allocate(
            make_state([2e6, 40e6, 1e6, 1e6], averages=[0.2e6, 40e6, 10e6, 10e6])
        )
        assert int(np.argmax(allocation)) == 0

    def test_alpha_zero_reduces_to_max_ci(self, context):
        pf = build_scheduler(
            "proportional_fair", context, np.random.default_rng(3), alpha=0.0
        )
        allocation = pf.allocate(make_state([1e6, 2e6, 50e6, 4e6], averages=[1e3, 1e3, 9e9, 1e3]))
        assert int(np.argmax(allocation)) == 2

    def test_is_robust_to_zero_history(self, context, rng):
        scheduler = build_scheduler("proportional_fair", context, rng)
        allocation = scheduler.allocate(make_state([10e6] * 4, averages=[0.0] * 4))
        assert np.isfinite(allocation).all()
        assert np.sum(allocation) == pytest.approx(1.0)

    def test_is_fairer_than_max_ci_over_time(self, context):
        """The central claim PF exists to make."""
        mean_rates = np.array([30e6, 20e6, 10e6, 2e6])
        airtime = {}
        for algorithm in ("proportional_fair", "max_ci"):
            scheduler = build_scheduler(algorithm, context, np.random.default_rng(11))
            served = np.zeros(4)
            average = np.full(4, 1.0)
            for slot in range(600):
                draw = np.random.default_rng(slot).exponential(mean_rates)
                allocation = scheduler.allocate(
                    make_state(list(draw), averages=list(average), slot=slot)
                )
                served += allocation
                average = 0.99 * average + 0.01 * (allocation * draw)
            airtime[algorithm] = served

        assert airtime["proportional_fair"].min() > airtime["max_ci"].min()
