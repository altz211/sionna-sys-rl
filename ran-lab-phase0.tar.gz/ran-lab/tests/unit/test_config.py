"""Tests for configuration composition, validation and hashing."""

from __future__ import annotations

import pytest

from ranlab.config import (
    Config,
    ConfigError,
    compose,
    condition_hash,
    resolve_overrides,
    save_config,
)


class TestComposition:
    def test_defaults_compose(self, config_dir):
        config = compose(config_dir)
        assert isinstance(config, Config)
        assert config.scheduler.algorithm == "round_robin"
        assert config.scenario.layout == "hex_grid"

    def test_group_override_swaps_option_file(self, config_dir):
        config = compose(config_dir, overrides=["scheduler=max_ci"])
        assert config.scheduler.algorithm == "max_ci"
        assert config.scheduler.name == "Max C/I"

    def test_leaf_override_sets_single_value(self, config_dir):
        config = compose(config_dir, overrides=["scenario.n_ue_per_cell=42"])
        assert config.scenario.n_ue_per_cell == 42

    def test_leaf_override_parses_yaml_scalars(self, config_dir):
        config = compose(
            config_dir,
            overrides=[
                "scenario.ue_speed_kmph=30.5",
                "channel.include_interference=false",
                "run.tag=null",
            ],
        )
        assert config.scenario.ue_speed_kmph == pytest.approx(30.5)
        assert config.channel.include_interference is False
        assert config.run.tag is None

    def test_leaf_override_beats_group_override(self, config_dir):
        config = compose(config_dir, overrides=["sim=long", "sim.n_slots=7"])
        assert config.sim.n_slots == 7
        assert config.sim.warmup_slots == 500  # rest of the group still applies


class TestValidation:
    def test_unknown_group_is_rejected(self, config_dir):
        with pytest.raises(ConfigError, match="unknown configuration group"):
            compose(config_dir, overrides=["nonexistent=thing"])

    def test_unknown_leaf_is_rejected(self, config_dir):
        with pytest.raises(ConfigError, match="does not exist"):
            compose(config_dir, overrides=["scenario.not_a_field=1"])

    def test_malformed_override_is_rejected(self, config_dir):
        with pytest.raises(ConfigError, match="malformed override"):
            compose(config_dir, overrides=["no_equals_sign"])

    def test_missing_option_file_is_rejected(self, config_dir):
        with pytest.raises(ConfigError, match="not found"):
            compose(config_dir, overrides=["scheduler=does_not_exist"])

    def test_out_of_range_value_is_rejected(self, config_dir):
        with pytest.raises(ConfigError, match="validation"):
            compose(config_dir, overrides=["phy.target_bler=1.5"])

    def test_learned_scheduler_requires_checkpoint(self, config_dir):
        with pytest.raises(ConfigError, match="policy_checkpoint"):
            compose(config_dir, overrides=["scheduler=learned",
                                           "scheduler.policy_checkpoint=null"])

    def test_single_cell_with_interference_is_rejected(self, config_dir):
        """A guard against a silently meaningless experiment."""
        with pytest.raises(ConfigError, match="single cell"):
            compose(
                config_dir,
                overrides=["scenario=single_cell", "channel.include_interference=true"],
            )

    def test_config_is_frozen(self, base_config):
        with pytest.raises(Exception):
            base_config.scenario.n_ue_per_cell = 99  # type: ignore[misc]


class TestOverrideParsing:
    def test_splits_groups_from_leaves(self):
        groups, leaves = resolve_overrides(["scheduler=max_ci", "run.seed=3"])
        assert groups == {"scheduler": "max_ci"}
        assert leaves == {"run.seed": 3}

    def test_empty_input(self):
        assert resolve_overrides(None) == ({}, {})


class TestConditionHash:
    def test_is_deterministic(self, config_dir):
        a = compose(config_dir, overrides=["scheduler=max_ci"])
        b = compose(config_dir, overrides=["scheduler=max_ci"])
        assert condition_hash(a) == condition_hash(b)

    def test_is_invariant_to_seed(self, config_dir):
        """The hash identifies the condition, so seeds must group together."""
        a = compose(config_dir, overrides=["run.seed=1"])
        b = compose(config_dir, overrides=["run.seed=999"])
        assert condition_hash(a) == condition_hash(b)

    def test_is_invariant_to_output_location(self, config_dir):
        a = compose(config_dir, overrides=["run.output_dir=results/raw"])
        b = compose(config_dir, overrides=["run.output_dir=/tmp/elsewhere"])
        assert condition_hash(a) == condition_hash(b)

    def test_changes_with_physical_parameters(self, config_dir):
        a = compose(config_dir, overrides=["scenario.n_ue_per_cell=5"])
        b = compose(config_dir, overrides=["scenario.n_ue_per_cell=6"])
        assert condition_hash(a) != condition_hash(b)

    def test_changes_with_policy(self, config_dir):
        a = compose(config_dir, overrides=["scheduler=round_robin"])
        b = compose(config_dir, overrides=["scheduler=proportional_fair"])
        assert condition_hash(a) != condition_hash(b)


class TestSerialisation:
    def test_round_trips_through_yaml(self, base_config, tmp_path, config_dir):
        path = save_config(base_config, tmp_path / "resolved.yaml")
        assert path.is_file()
        reloaded = Config.model_validate(
            __import__("yaml").safe_load(path.read_text(encoding="utf-8"))
        )
        assert condition_hash(reloaded) == condition_hash(base_config)


class TestDerivedProperties:
    @pytest.mark.parametrize(
        ("n_rings", "expected_sites"), [(0, 1), (1, 7), (2, 19), (3, 37)]
    )
    def test_site_count_matches_hex_lattice(self, config_dir, n_rings, expected_sites):
        config = compose(config_dir, overrides=[f"scenario.n_rings={n_rings}"])
        assert config.scenario.n_sites == expected_sites
        assert config.scenario.n_cells == expected_sites * 3
