"""Tests for deployment geometry."""

from __future__ import annotations

import numpy as np
import pytest

from ranlab.config import ScenarioConfig
from ranlab.scenario import build_deployment, hex_site_positions


class TestHexLattice:
    @pytest.mark.parametrize(
        ("n_rings", "expected"), [(0, 1), (1, 7), (2, 19), (3, 37)]
    )
    def test_site_count(self, n_rings, expected):
        assert hex_site_positions(n_rings, 200.0).shape == (expected, 2)

    def test_nearest_neighbour_distance_is_the_isd(self):
        """The defining property of the layout; an error here silently rescales
        every path loss in the simulation."""
        isd = 200.0
        sites = hex_site_positions(1, isd)
        distances = np.linalg.norm(sites[:, None, :] - sites[None, :, :], axis=-1)
        np.fill_diagonal(distances, np.inf)
        assert distances.min(axis=1) == pytest.approx(isd, rel=1e-9)

    def test_centre_site_is_at_the_origin(self):
        sites = hex_site_positions(2, 500.0)
        assert np.min(np.linalg.norm(sites, axis=1)) == pytest.approx(0.0)

    def test_layout_is_centrally_symmetric(self):
        sites = hex_site_positions(2, 200.0)
        assert np.allclose(sites.sum(axis=0), 0.0, atol=1e-9)


class TestDeployment:
    @pytest.fixture
    def scenario(self) -> ScenarioConfig:
        return ScenarioConfig(name="test", n_rings=1, sectors_per_site=3,
                              n_ue_per_cell=5, isd_m=200.0)

    def test_dimensions_are_consistent(self, scenario, rng):
        d = build_deployment(scenario, rng)
        assert d.n_sites == 7
        assert d.n_cells == 21
        assert d.n_ue == 21 * 5
        assert d.serving_cell.shape == (d.n_ue,)

    def test_cells_are_colocated_with_their_site(self, scenario, rng):
        d = build_deployment(scenario, rng)
        np.testing.assert_allclose(d.cell_xy, d.site_xy[d.cell_site_id])

    def test_sector_boresights_are_evenly_spaced(self, scenario, rng):
        d = build_deployment(scenario, rng)
        first_site = d.cell_boresight_rad[:3]
        gaps = np.diff(np.sort(first_site))
        assert gaps == pytest.approx(2 * np.pi / 3, rel=1e-6)

    def test_minimum_separation_is_respected(self, scenario, rng):
        d = build_deployment(scenario, rng)
        assert d.distance_matrix().min() >= scenario.min_bs_ue_distance_m - 1e-6

    def test_serving_cell_index_is_in_range(self, scenario, rng):
        d = build_deployment(scenario, rng)
        assert d.serving_cell.min() >= 0
        assert d.serving_cell.max() < d.n_cells

    def test_is_deterministic_given_a_seed(self, scenario):
        a = build_deployment(scenario, np.random.default_rng(42))
        b = build_deployment(scenario, np.random.default_rng(42))
        np.testing.assert_array_equal(a.ue_xy, b.ue_xy)
        np.testing.assert_array_equal(a.serving_cell, b.serving_cell)

    def test_different_seeds_give_different_drops(self, scenario):
        a = build_deployment(scenario, np.random.default_rng(1))
        b = build_deployment(scenario, np.random.default_rng(2))
        assert not np.allclose(a.ue_xy, b.ue_xy)

    def test_wrap_around_shortens_distances_across_the_boundary(self, rng):
        """Without wrap-around, edge cells see too little interference and every
        interference statistic in the study is biased."""
        wrapped = ScenarioConfig(name="w", n_rings=1, n_ue_per_cell=5, wrap_around=True)
        plain = ScenarioConfig(name="p", n_rings=1, n_ue_per_cell=5, wrap_around=False)
        d_wrapped = build_deployment(wrapped, np.random.default_rng(3))
        d_plain = build_deployment(plain, np.random.default_rng(3))
        assert d_wrapped.distance_matrix().max() < d_plain.distance_matrix().max()

    def test_real_topology_is_not_yet_implemented(self, rng):
        scenario = ScenarioConfig(
            name="real", layout="real_topology", topology_file="sites.csv"
        )
        with pytest.raises(NotImplementedError, match="Phase 5"):
            build_deployment(scenario, rng)
