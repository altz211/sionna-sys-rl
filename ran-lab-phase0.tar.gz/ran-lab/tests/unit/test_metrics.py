"""Tests for KPI computation and statistical aggregation."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from ranlab.metrics import (
    aggregate_over_seeds,
    bootstrap_ci,
    cohens_d,
    compare_conditions,
    energy_per_bit_nj,
    jain_fairness,
    mean_ci,
    spectral_efficiency,
    summarise_throughput,
    total_energy_j,
)


class TestJainFairness:
    def test_equal_allocation_is_one(self):
        assert jain_fairness(np.ones(10)) == pytest.approx(1.0)

    def test_single_winner_is_one_over_n(self):
        x = np.zeros(10)
        x[0] = 1.0
        assert jain_fairness(x) == pytest.approx(0.1)

    def test_is_scale_invariant(self):
        x = np.array([1.0, 2.0, 3.0, 4.0])
        assert jain_fairness(x) == pytest.approx(jain_fairness(x * 1000.0))

    def test_is_bounded(self, rng):
        for _ in range(20):
            x = rng.exponential(size=25)
            assert 0.0 <= jain_fairness(x) <= 1.0

    def test_empty_input_is_nan(self):
        assert np.isnan(jain_fairness(np.array([])))


class TestThroughputSummary:
    def test_percentiles_are_ordered(self, rng):
        summary = summarise_throughput(rng.exponential(scale=5e6, size=500))
        assert summary["p5"] <= summary["p50"] <= summary["p95"]

    def test_total_is_the_sum(self):
        x = np.array([1.0, 2.0, 3.0])
        assert summarise_throughput(x)["total"] == pytest.approx(6.0)

    def test_empty_input_is_all_nan(self):
        assert all(np.isnan(v) for v in summarise_throughput(np.array([])).values())


class TestEnergy:
    def test_scales_with_cells_and_duration(self):
        one = total_energy_j(1, 44.0, 130.0, 0.35, 1.0)
        many = total_energy_j(7, 44.0, 130.0, 0.35, 2.0)
        assert many == pytest.approx(one * 14.0)

    def test_includes_circuit_and_radiated_power(self):
        """44 dBm is 25.12 W; at 35% PA efficiency that is 71.8 W radiated cost."""
        energy = total_energy_j(1, 44.0, 130.0, 0.35, 1.0)
        expected = 130.0 + (10 ** ((44.0 - 30.0) / 10.0)) / 0.35
        assert energy == pytest.approx(expected)

    def test_energy_per_bit_units(self):
        # 1 J over 1 Gbit is 1 nJ/bit.
        assert energy_per_bit_nj(1.0, 1e9) == pytest.approx(1.0)

    def test_zero_bits_is_nan(self):
        assert np.isnan(energy_per_bit_nj(10.0, 0.0))


class TestSpectralEfficiency:
    def test_basic_ratio(self):
        assert spectral_efficiency(20e6, 20e6, 1) == pytest.approx(1.0)

    def test_divides_by_cell_count(self):
        assert spectral_efficiency(40e6, 20e6, 2) == pytest.approx(1.0)


class TestStatistics:
    def test_bootstrap_ci_brackets_the_mean(self, rng):
        x = rng.normal(100.0, 10.0, size=200)
        low, high = bootstrap_ci(x, seed=0)
        assert low < np.mean(x) < high

    def test_bootstrap_ci_narrows_with_sample_size(self, rng):
        small = bootstrap_ci(rng.normal(0, 1, 10), seed=0)
        large = bootstrap_ci(rng.normal(0, 1, 1000), seed=0)
        assert (large[1] - large[0]) < (small[1] - small[0])

    def test_single_observation_is_degenerate(self):
        assert bootstrap_ci(np.array([5.0])) == (5.0, 5.0)

    def test_mean_ci_reports_sample_size(self, rng):
        summary = mean_ci(rng.normal(size=50))
        assert summary["n"] == 50

    def test_mean_ci_ignores_non_finite(self):
        summary = mean_ci(np.array([1.0, 2.0, np.nan, np.inf]))
        assert summary["n"] == 2
        assert summary["mean"] == pytest.approx(1.5)

    def test_cohens_d_sign_and_magnitude(self, rng):
        a = rng.normal(1.0, 1.0, 500)
        b = rng.normal(0.0, 1.0, 500)
        assert cohens_d(a, b) == pytest.approx(1.0, abs=0.25)
        assert cohens_d(b, a) < 0


@pytest.fixture
def results_frame(rng) -> pd.DataFrame:
    """A synthetic results table: two policies, five seeds each."""
    rows = []
    for policy, level in (("Round Robin", 10.0), ("Proportional Fair", 12.0)):
        for seed in range(5):
            rows.append(
                {
                    "condition_hash": f"hash_{policy}",
                    "scheduler": policy,
                    "seed": seed,
                    "mean_ue_throughput_bps": level + rng.normal(0, 0.3),
                    "jain_fairness": 0.8,
                }
            )
    return pd.DataFrame(rows)


class TestAggregation:
    def test_collapses_seeds_into_conditions(self, results_frame):
        out = aggregate_over_seeds(results_frame, metrics=["mean_ue_throughput_bps"])
        assert len(out) == 2
        assert set(out["n_seeds"]) == {5}

    def test_emits_mean_and_interval_columns(self, results_frame):
        out = aggregate_over_seeds(results_frame, metrics=["mean_ue_throughput_bps"])
        for suffix in ("_mean", "_std", "_ci_low", "_ci_high"):
            assert f"mean_ue_throughput_bps{suffix}" in out.columns

    def test_interval_contains_mean(self, results_frame):
        out = aggregate_over_seeds(results_frame, metrics=["mean_ue_throughput_bps"])
        assert (
            (out["mean_ue_throughput_bps_ci_low"] <= out["mean_ue_throughput_bps_mean"])
            & (out["mean_ue_throughput_bps_mean"] <= out["mean_ue_throughput_bps_ci_high"])
        ).all()

    def test_missing_metric_raises(self, results_frame):
        with pytest.raises(KeyError):
            aggregate_over_seeds(results_frame, metrics=["not_a_metric"])


class TestComparison:
    def test_detects_a_real_difference(self, results_frame):
        result = compare_conditions(
            results_frame, "mean_ue_throughput_bps", "scheduler",
            baseline="Round Robin", candidate="Proportional Fair",
        )
        assert result["absolute_delta"] > 0
        assert result["p_value"] < 0.05
        assert result["paired"] is True

    def test_relative_delta_is_a_percentage(self, results_frame):
        result = compare_conditions(
            results_frame, "mean_ue_throughput_bps", "scheduler",
            baseline="Round Robin", candidate="Proportional Fair",
        )
        assert result["relative_delta_pct"] == pytest.approx(20.0, abs=5.0)

    def test_unknown_condition_raises(self, results_frame):
        with pytest.raises(KeyError):
            compare_conditions(
                results_frame, "mean_ue_throughput_bps", "scheduler",
                baseline="Round Robin", candidate="Nonexistent",
            )
