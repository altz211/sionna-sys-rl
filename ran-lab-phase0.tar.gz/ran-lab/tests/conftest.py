"""Shared pytest fixtures."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from ranlab.config import Config, compose

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = REPO_ROOT / "configs"


@pytest.fixture(scope="session")
def config_dir() -> Path:
    """Path to the repository's configuration directory."""
    return CONFIG_DIR


@pytest.fixture
def base_config() -> Config:
    """A small, fast configuration suitable for unit tests."""
    return compose(
        CONFIG_DIR,
        overrides=["sim=quick", "scenario.n_ue_per_cell=3", "scenario.n_rings=0",
                   "scenario.sectors_per_site=3"],
    )


@pytest.fixture
def rng() -> np.random.Generator:
    """A seeded generator, so every test is deterministic."""
    return np.random.default_rng(12345)
