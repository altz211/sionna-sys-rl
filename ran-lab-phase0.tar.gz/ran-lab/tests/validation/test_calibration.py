"""Phase-1 validation gates — currently skipped.

A validation test does not check that the code runs; it checks that the model
reproduces a result somebody else published.  Until these pass, no number this
repository produces should be quoted as a result, and the generated report
says so on its face.

Each test below names the reference it will be checked against.  They are
written now, failing-by-skip, so that the acceptance criteria for Phase 1 are
recorded in the repository rather than in somebody's memory.
"""

from __future__ import annotations

import pytest

pytestmark = pytest.mark.validation

PHASE_1 = "Phase 1: awaiting the TR 38.901 channel model and EESM abstraction"


@pytest.mark.skip(reason=PHASE_1)
def test_umi_sinr_cdf_matches_reference():
    """Wideband SINR CDF against the 3GPP UMi calibration reference.

    Reference: 3GPP TR 38.901 / TR 36.873 calibration results for UMi Street
    Canyon, 200 m ISD, 3.5 GHz, 3-sector sites.

    Gate: the 5th, 50th and 95th percentiles must each fall within 1.5 dB of
    the reference curve. The SINR distribution is upstream of every other KPI,
    so if it is wrong, nothing downstream is worth measuring.
    """


@pytest.mark.skip(reason=PHASE_1)
def test_coupling_loss_cdf_matches_reference():
    """Coupling loss (path loss minus antenna gain) against the same reference.

    Separates a propagation error from an interference-modelling error: coupling
    loss depends only on the link budget, so a mismatch here localises the bug
    to path loss, shadowing or the antenna pattern.
    """


@pytest.mark.skip(reason=PHASE_1)
def test_eesm_reproduces_link_level_bler_curves():
    """EESM effective SINR against tabulated NR link-level BLER curves.

    Gate: for each MCS, the SINR at 10% BLER must be within 0.5 dB of the
    link-level curve it abstracts.
    """


@pytest.mark.skip(reason=PHASE_1)
def test_single_cell_capacity_approaches_shannon():
    """A noise-limited single cell must approach the Shannon bound.

    With interference disabled, ideal link adaptation and no implementation
    loss, per-UE spectral efficiency must track log2(1 + SINR) to within the
    modelled implementation margin. Catches unit errors in the link budget,
    which otherwise hide as a plausible-looking constant offset.
    """


@pytest.mark.skip(reason="Phase 2: awaiting the FTP Model 3 traffic implementation")
def test_little_law_holds_under_ftp3():
    """Mean queue length must equal arrival rate times mean latency.

    Little's law is an identity, not an approximation, so any violation is an
    accounting bug in the buffer or latency instrumentation.
    """


@pytest.mark.skip(reason="Phase 4: awaiting the learned policy")
def test_learned_policy_receives_no_privileged_information():
    """The learned policy must observe exactly the baselines' state.

    Gate: with the learned policy's weights frozen to imitate PF, its KPIs must
    match the PF baseline to within seed noise. A discrepancy means the RL
    observation exposes something the classical policies cannot see, and any
    reported gain would be an artefact.
    """
