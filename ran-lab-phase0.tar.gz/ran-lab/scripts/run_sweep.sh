#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Run a declared experiment and archive the results under a timestamped
# directory, so successive sweeps never silently overwrite one another.
#
#   ./scripts/run_sweep.sh [experiment] [workers] [extra overrides...]
#   ./scripts/run_sweep.sh sweep_density 8 run=multiseed
# -----------------------------------------------------------------------------
set -Eeuo pipefail

EXPERIMENT="${1:-scheduler_comparison}"
WORKERS="${2:-4}"
shift $(( $# > 2 ? 2 : $# )) || true
EXTRA_OVERRIDES=("$@")

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
ARCHIVE_DIR="results/archive/${EXPERIMENT}_${STAMP}"

log() { printf '\033[36m==>\033[0m %s\n' "$*"; }

if [[ -d .venv && -z "${VIRTUAL_ENV:-}" ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

command -v ranlab >/dev/null 2>&1 || {
  printf '\033[31mERROR:\033[0m ranlab not found. Run ./scripts/setup_env.sh first.\n' >&2
  exit 1
}

REVISION="$(git rev-parse --short HEAD 2>/dev/null || echo 'no-git')"
if ! git diff --quiet 2>/dev/null || ! git diff --cached --quiet 2>/dev/null; then
  printf '\033[33mWARNING:\033[0m working tree is dirty; results will be flagged as non-reproducible.\n'
fi

log "Experiment : ${EXPERIMENT}"
log "Revision   : ${REVISION}"
log "Workers    : ${WORKERS}"
log "Archive    : ${ARCHIVE_DIR}"

mkdir -p "$ARCHIVE_DIR"

log "Planned runs:"
ranlab sweep "experiment=${EXPERIMENT}" "${EXTRA_OVERRIDES[@]}" --dry-run

START=$(date +%s)
ranlab sweep \
  "experiment=${EXPERIMENT}" \
  "${EXTRA_OVERRIDES[@]}" \
  --workers "${WORKERS}" \
  --output-dir "${ARCHIVE_DIR}"
ELAPSED=$(( $(date +%s) - START ))

log "Sweep finished in ${ELAPSED}s"

# Publish into the working results directory that `make report` reads.
mkdir -p results/raw
cp "${ARCHIVE_DIR}"/*.parquet "${ARCHIVE_DIR}"/*.json results/raw/ 2>/dev/null || true

log "Archived to ${ARCHIVE_DIR}; published to results/raw"
log "Next: make report"
