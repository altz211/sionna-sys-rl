#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Summarise what is currently in the results directory: how many runs, which
# conditions, which code revisions, and whether any run came from a dirty tree.
#
#   ./scripts/collect_results.sh [results_dir]
# -----------------------------------------------------------------------------
set -Eeuo pipefail

RESULTS_DIR="${1:-results/raw}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

if [[ -d .venv && -z "${VIRTUAL_ENV:-}" ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

if ! compgen -G "${RESULTS_DIR}/*.run.parquet" >/dev/null; then
  printf '\033[31mERROR:\033[0m no results found in %s. Run a sweep first.\n' "$RESULTS_DIR" >&2
  exit 1
fi

n_runs=$(find "$RESULTS_DIR" -name '*.run.parquet' | wc -l | tr -d ' ')
disk=$(du -sh "$RESULTS_DIR" | cut -f1)

printf '\033[36m==>\033[0m %s run(s) in %s (%s on disk)\n\n' "$n_runs" "$RESULTS_DIR" "$disk"

python3 - "$RESULTS_DIR" <<'PYTHON'
import sys
from ranlab.io import load_results

df = load_results(sys.argv[1], level="run")

print(f"{'experiment':<26}{'policy':<20}{'conds':>6}{'seeds':>7}{'runs':>6}")
print("-" * 65)
for (experiment, policy), group in df.groupby(["experiment", "scheduler"], sort=True):
    print(
        f"{experiment:<26}{policy:<20}"
        f"{group['condition_hash'].nunique():>6}"
        f"{group['seed'].nunique():>7}"
        f"{len(group):>6}"
    )

revisions = sorted(df["git_commit"].dropna().unique())
print()
if not revisions:
    print("WARNING: no git revision recorded — results cannot be tied to a code version.")
else:
    print(f"code revision(s): {', '.join(r[:12] for r in revisions)}")
    if len(revisions) > 1:
        print("WARNING: results span multiple revisions and are not directly comparable.")

dirty = df["git_dirty"].dropna()
if len(dirty) and bool(dirty.any()):
    print(f"WARNING: {int(dirty.sum())} run(s) came from a dirty working tree.")
PYTHON
