#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Regenerate every figure and the HTML report from recorded results.
# Figures are always derived from the Parquet tables, never hand-edited — that
# is what makes "make report" a reproduction rather than a re-render.
#
#   ./scripts/make_figures.sh [experiment]
# -----------------------------------------------------------------------------
set -Eeuo pipefail

EXPERIMENT="${1:-}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

RESULTS_DIR="${RESULTS_DIR:-results/raw}"
FIGURES_DIR="${FIGURES_DIR:-results/figures}"
REPORT="${REPORT:-results/processed/report.html}"

log() { printf '\033[36m==>\033[0m %s\n' "$*"; }

if [[ -d .venv && -z "${VIRTUAL_ENV:-}" ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

export MPLBACKEND=Agg

mkdir -p "$FIGURES_DIR" "$(dirname "$REPORT")"
rm -f "${FIGURES_DIR}"/*.png

args=(--results-dir "$RESULTS_DIR" --figures-dir "$FIGURES_DIR" --output "$REPORT")
[[ -n "$EXPERIMENT" ]] && args+=(--experiment "$EXPERIMENT")

log "Building figures and report"
ranlab report "${args[@]}"

n_figures=$(find "$FIGURES_DIR" -name '*.png' | wc -l | tr -d ' ')
log "${n_figures} figure(s) -> ${FIGURES_DIR}"
log "report -> ${REPORT}"
