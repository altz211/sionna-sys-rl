#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Create the development environment and verify the installation.
#
#   ./scripts/setup_env.sh [venv_dir]
# -----------------------------------------------------------------------------
set -Eeuo pipefail

VENV_DIR="${1:-.venv}"
PYTHON="${PYTHON:-python3}"
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log() { printf '\033[36m==>\033[0m %s\n' "$*"; }
die() { printf '\033[31mERROR:\033[0m %s\n' "$*" >&2; exit 1; }

cd "$REPO_ROOT"

command -v "$PYTHON" >/dev/null 2>&1 || die "$PYTHON not found on PATH"

version="$("$PYTHON" -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
required="3.10"
if [[ "$(printf '%s\n%s\n' "$required" "$version" | sort -V | head -n1)" != "$required" ]]; then
  die "Python >= $required required, found $version"
fi
log "Python $version"

if [[ ! -d "$VENV_DIR" ]]; then
  log "Creating virtualenv at $VENV_DIR"
  "$PYTHON" -m venv "$VENV_DIR"
fi

# shellcheck disable=SC1091
source "$VENV_DIR/bin/activate"

log "Installing ranlab with development extras"
pip install --quiet --upgrade pip setuptools wheel
pip install --quiet -e ".[dev]"

log "Verifying installation"
ranlab --version
ranlab config >/dev/null || die "default configuration failed to compose"

if ! git rev-parse --git-dir >/dev/null 2>&1; then
  cat <<'WARN'

  WARNING: this directory is not a git repository.
  Provenance capture records the code revision behind every result; without
  git, results will be stamped with no revision and flagged as
  non-reproducible in the generated report.

      git init && git add -A && git commit -m "Initial commit"

WARN
fi

log "Done. Activate with: source $VENV_DIR/bin/activate"
