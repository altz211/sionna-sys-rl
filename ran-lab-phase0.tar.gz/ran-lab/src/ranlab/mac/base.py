"""Scheduler interface.

Every resource-management policy — classical or learned — implements this one
interface and receives exactly the same :class:`SlotState`.  That symmetry is
a methodological requirement, not a convenience: if the learned policy could
observe anything the baselines cannot, any improvement it showed would be
uninterpretable.

The allocation is expressed as a vector of PRB shares over UEs rather than a
single selected UE index.  Single-user-per-slot policies simply return a
one-hot vector, but the wider interface leaves room for the multi-user and
fractional allocations a learned policy may produce, without a later
interface change invalidating earlier results.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import numpy as np

__all__ = ["SchedulerContext", "SlotState", "Scheduler", "register", "build_scheduler"]


@dataclass(frozen=True)
class SchedulerContext:
    """Static parameters known to the policy before the run starts."""

    n_ue: int
    n_prb: int
    slot_duration_s: float
    bandwidth_hz: float


@dataclass
class SlotState:
    """Everything a policy may observe at the start of one scheduling slot.

    Attributes
    ----------
    slot
        Slot index since the start of the run, including warm-up.
    achievable_rate_bps
        Per-UE rate if the UE were given all PRBs this slot, derived from the
        reported CQI.  This is a *reported* quantity and therefore already
        carries measurement delay and quantisation: the policy never sees the
        true instantaneous channel.
    avg_throughput_bps
        Per-UE exponentially-weighted delivered throughput so far.  This is
        the state variable that makes proportional fairness possible.
    has_data
        Whether the UE currently has buffered data (always True under
        full-buffer traffic).
    buffer_bits
        Per-UE queued payload, for finite-buffer traffic models.
    hol_delay_slots
        Head-of-line delay per UE, in slots; the basis of any latency-aware
        policy.
    """

    slot: int
    achievable_rate_bps: np.ndarray
    avg_throughput_bps: np.ndarray
    has_data: np.ndarray
    buffer_bits: np.ndarray | None = None
    hol_delay_slots: np.ndarray | None = None
    extras: dict[str, np.ndarray] = field(default_factory=dict)


class Scheduler(ABC):
    """Abstract downlink resource-allocation policy."""

    #: Short identifier used in the results tables and plot legends.
    algorithm: str = "abstract"

    def __init__(self, context: SchedulerContext, rng: np.random.Generator) -> None:
        self.context = context
        self.rng = rng

    @abstractmethod
    def allocate(self, state: SlotState) -> np.ndarray:
        """Return per-UE PRB shares for this slot.

        The returned vector has length ``context.n_ue``, is non-negative, and
        sums to at most 1.0.  Returning all zeros means the slot is not used.
        """

    def reset(self) -> None:
        """Reset any internal state between independent runs."""
        return None

    # -- helpers available to every policy ---------------------------------

    @staticmethod
    def _one_hot(index: int, n_ue: int) -> np.ndarray:
        allocation = np.zeros(n_ue, dtype=np.float64)
        allocation[index] = 1.0
        return allocation

    @staticmethod
    def _idle(n_ue: int) -> np.ndarray:
        return np.zeros(n_ue, dtype=np.float64)

    def _argmax_with_random_tiebreak(self, metric: np.ndarray, eligible: np.ndarray) -> int | None:
        """Argmax over eligible UEs, breaking ties uniformly at random.

        Deterministic tie-breaking (``np.argmax``) systematically favours
        low-indexed UEs, which biases fairness statistics in exactly the
        experiments those statistics are meant to measure.
        """
        if not np.any(eligible):
            return None
        masked = np.where(eligible, metric, -np.inf)
        best = np.max(masked)
        if not np.isfinite(best):
            return None
        winners = np.flatnonzero(masked >= best - 1e-12)
        return int(self.rng.choice(winners))


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_REGISTRY: dict[str, type[Scheduler]] = {}


def register(cls: type[Scheduler]) -> type[Scheduler]:
    """Class decorator registering a policy under its ``algorithm`` name."""
    if cls.algorithm in _REGISTRY:
        raise ValueError(f"scheduler '{cls.algorithm}' is already registered")
    _REGISTRY[cls.algorithm] = cls
    return cls


def build_scheduler(
    algorithm: str,
    context: SchedulerContext,
    rng: np.random.Generator,
    **kwargs: object,
) -> Scheduler:
    """Instantiate a registered policy by name."""
    # Import for side-effect registration; deferred to avoid a circular import.
    from ranlab.mac import policies  # noqa: F401

    if algorithm not in _REGISTRY:
        raise KeyError(
            f"unknown scheduler '{algorithm}'. Registered: {sorted(_REGISTRY)}"
        )
    return _REGISTRY[algorithm](context=context, rng=rng, **kwargs)  # type: ignore[arg-type]
