"""Classical scheduling baselines.

These three policies bracket the achievable throughput/fairness region and
are the reference against which any learned policy must be judged:

==================  ====================  =================  =================
Policy              Aggregate throughput  Airtime fairness   Throughput Jain
==================  ====================  =================  =================
Round Robin         lowest                highest (exact)    high
Proportional Fair   intermediate          high               high
Max C/I             highest               lowest             lowest
==================  ====================  =================  =================

Reproducing the **throughput** ordering is the Phase-2 validation gate:
``max_ci > proportional_fair > round_robin``.  A simulator that does not
reproduce it has a bug, and no result obtained from it is meaningful.

Fairness needs a sharper statement, because the two common definitions do not
agree.  Round Robin is fairest in *airtime* by construction — it hands every
backlogged UE an equal share of slots.  It is not necessarily fairest in
*throughput*: equal airtime converts into unequal bits, because a cell-edge UE
turns its slots into far fewer of them.  Proportional Fair allocates airtime
close to equally while additionally riding the fading peaks, so it often
attains both higher aggregate throughput *and* a higher Jain index on
throughput than Round Robin.  The robust, definition-independent claim — and
the one used as the gate — is that Max C/I is least fair on both measures.
"""

from __future__ import annotations

import numpy as np

from ranlab.mac.base import Scheduler, SchedulerContext, SlotState, register

__all__ = ["MaxCI", "ProportionalFair", "RoundRobin"]


@register
class RoundRobin(Scheduler):
    """Cyclic allocation, channel-unaware.

    Serves the next UE with data in a fixed rotation, ignoring channel
    quality entirely.  Maximises equality of *airtime*, not of throughput:
    cell-edge UEs receive the same number of slots as cell-centre UEs but
    convert them into far fewer bits.
    """

    algorithm = "round_robin"

    def __init__(self, context: SchedulerContext, rng: np.random.Generator) -> None:
        super().__init__(context, rng)
        self._pointer = 0

    def reset(self) -> None:
        self._pointer = 0

    def allocate(self, state: SlotState) -> np.ndarray:
        n_ue = self.context.n_ue
        for offset in range(n_ue):
            candidate = (self._pointer + offset) % n_ue
            if state.has_data[candidate]:
                self._pointer = (candidate + 1) % n_ue
                return self._one_hot(candidate, n_ue)
        return self._idle(n_ue)


@register
class MaxCI(Scheduler):
    """Greedy max-rate allocation.

    Always serves the UE with the best reported channel.  Maximises aggregate
    throughput and minimises fairness; under static channels it starves
    cell-edge UEs completely.  Included as the throughput upper bound.
    """

    algorithm = "max_ci"

    def allocate(self, state: SlotState) -> np.ndarray:
        eligible = state.has_data & (state.achievable_rate_bps > 0)
        winner = self._argmax_with_random_tiebreak(state.achievable_rate_bps, eligible)
        if winner is None:
            return self._idle(self.context.n_ue)
        return self._one_hot(winner, self.context.n_ue)


@register
class ProportionalFair(Scheduler):
    r"""Proportional-fair allocation.

    Serves the UE maximising

    .. math:: M_i = \frac{R_i^{\beta}}{\bar{T}_i^{\alpha}}

    where :math:`R_i` is the instantaneous achievable rate and
    :math:`\bar{T}_i` the exponentially-weighted delivered throughput.  With
    :math:`\alpha = \beta = 1` this is the classical PF rule, whose fixed
    point maximises :math:`\sum_i \log \bar{T}_i`.

    The throughput average is maintained by the simulator, not by the policy,
    so that every policy observes an identically-defined state.
    """

    algorithm = "proportional_fair"

    def __init__(
        self,
        context: SchedulerContext,
        rng: np.random.Generator,
        alpha: float = 1.0,
        beta: float = 1.0,
        epsilon: float = 1.0,
    ) -> None:
        super().__init__(context, rng)
        self.alpha = float(alpha)
        self.beta = float(beta)
        # Floor on the throughput average, so a UE that has never been served
        # yields a finite (and very large) metric instead of dividing by zero.
        self.epsilon = float(epsilon)

    def allocate(self, state: SlotState) -> np.ndarray:
        eligible = state.has_data & (state.achievable_rate_bps > 0)
        if not np.any(eligible):
            return self._idle(self.context.n_ue)

        rate = np.maximum(state.achievable_rate_bps, 0.0)
        average = np.maximum(state.avg_throughput_bps, self.epsilon)

        with np.errstate(divide="ignore", invalid="ignore"):
            metric = np.power(rate, self.beta) / np.power(average, self.alpha)
        metric = np.nan_to_num(metric, nan=0.0, posinf=np.finfo(np.float64).max)

        winner = self._argmax_with_random_tiebreak(metric, eligible)
        if winner is None:
            return self._idle(self.context.n_ue)
        return self._one_hot(winner, self.context.n_ue)
