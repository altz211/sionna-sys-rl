"""Propagation channel models."""

from ranlab.channel.stub import (
    LargeScaleGain,
    compute_large_scale_gain,
    instantaneous_sinr_db,
)

__all__ = ["LargeScaleGain", "compute_large_scale_gain", "instantaneous_sinr_db"]
