"""Placeholder propagation model — PHASE 0 ONLY.

.. warning::

   This module is **not** a 3GPP channel model and its absolute numbers must
   never be quoted as results.  It exists so that the experiment harness, the
   result schema, the sweep runner and the reporting layer can be built,
   tested and exercised end to end before the physics is implemented, and so
   that continuous integration can run the whole pipeline in seconds without
   the heavyweight simulation backend.

   Phase 1 replaces it with ``ranlab.channel.tr38901``, validated against the
   published reference SINR distribution.  Until that validation gate passes,
   every figure produced from this module is plumbing evidence only.

What it does model, in a deliberately simple way:

* distance-dependent path loss with a fixed exponent,
* log-normal shadow fading, spatially uncorrelated,
* the TR 38.901 horizontal sector antenna pattern (shared with the real model),
* Rayleigh fast fading, independent across slots,
* inter-cell interference as the sum of received power from all other cells.

What it does **not** model: frequency selectivity, LOS/NLOS state, spatial
correlation of shadowing, realistic delay/Doppler spectra, or any of the
TR 38.901 large-scale parameters.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ranlab.config import ChannelConfig, PowerConfig, ScenarioConfig
from ranlab.scenario.layout import Deployment, _sector_antenna_gain_db

__all__ = ["LargeScaleGain", "compute_large_scale_gain", "instantaneous_sinr_db"]

#: Path-loss exponent of the placeholder model. A real model derives this from
#: frequency, geometry and LOS state; here it is a single fixed number, which
#: is exactly why the module is a placeholder.
_PATH_LOSS_EXPONENT = 3.5

#: Reference path loss at 1 m, free space at the configured carrier.
_REFERENCE_DISTANCE_M = 1.0


@dataclass(frozen=True)
class LargeScaleGain:
    """Slow-varying link gains that stay fixed for the duration of a run."""

    gain_db: np.ndarray  # (n_ue, n_cells) total large-scale gain
    distance_m: np.ndarray  # (n_ue, n_cells)
    noise_power_dbm: float


def _free_space_reference_db(carrier_frequency_hz: float) -> float:
    """Free-space path loss at the reference distance, in dB."""
    speed_of_light = 299_792_458.0
    wavelength = speed_of_light / carrier_frequency_hz
    return 20.0 * np.log10(4.0 * np.pi * _REFERENCE_DISTANCE_M / wavelength)


def compute_large_scale_gain(
    deployment: Deployment,
    scenario: ScenarioConfig,
    channel: ChannelConfig,
    rng: np.random.Generator,
) -> LargeScaleGain:
    """Path loss, shadowing and antenna gain for every UE-cell pair."""
    distance_2d = np.maximum(deployment.distance_matrix(), scenario.min_bs_ue_distance_m)
    height_difference = scenario.bs_height_m - scenario.ue_height_m
    distance_3d = np.sqrt(distance_2d**2 + height_difference**2)

    path_loss_db = _free_space_reference_db(channel.carrier_frequency_hz) + (
        10.0 * _PATH_LOSS_EXPONENT * np.log10(distance_3d / _REFERENCE_DISTANCE_M)
    )

    shadowing_db = rng.normal(0.0, channel.shadowing_std_db, size=distance_2d.shape)

    bearing = deployment.bearing_matrix()
    angle_off_boresight = np.angle(
        np.exp(1j * (bearing - deployment.cell_boresight_rad[None, :]))
    )
    antenna_gain_db = _sector_antenna_gain_db(angle_off_boresight, scenario.sectors_per_site)

    gain_db = antenna_gain_db - path_loss_db + shadowing_db

    noise_power_dbm = (
        channel.thermal_noise_dbm_per_hz
        + 10.0 * np.log10(channel.bandwidth_hz)
        + channel.noise_figure_db
    )

    return LargeScaleGain(
        gain_db=gain_db, distance_m=distance_2d, noise_power_dbm=float(noise_power_dbm)
    )


def instantaneous_sinr_db(
    large_scale: LargeScaleGain,
    deployment: Deployment,
    channel: ChannelConfig,
    power: PowerConfig,
    rng: np.random.Generator,
) -> np.ndarray:
    """One slot of per-UE SINR, in dB.

    Fast fading is drawn independently per slot and per link, i.e. a fully
    de-correlated Rayleigh channel.  That is an unrealistic extreme — it gives
    channel-aware schedulers the maximum possible multi-user diversity gain —
    and is another reason Phase-0 numbers are not results.
    """
    n_ue, n_cells = large_scale.gain_db.shape

    linear_gain = 10.0 ** (large_scale.gain_db / 10.0)
    # Rayleigh amplitude => exponential power gain with unit mean.
    fast_fading = rng.exponential(scale=1.0, size=(n_ue, n_cells))

    tx_power_mw = 10.0 ** (power.tx_power_dbm / 10.0)
    received_mw = tx_power_mw * linear_gain * fast_fading

    ue_index = np.arange(n_ue)
    serving_mw = received_mw[ue_index, deployment.serving_cell]

    noise_mw = 10.0 ** (large_scale.noise_power_dbm / 10.0)
    if channel.include_interference:
        interference_mw = received_mw.sum(axis=1) - serving_mw
    else:
        interference_mw = 0.0

    sinr_linear = serving_mw / (interference_mw + noise_mw)
    return 10.0 * np.log10(np.maximum(sinr_linear, 1e-12))
