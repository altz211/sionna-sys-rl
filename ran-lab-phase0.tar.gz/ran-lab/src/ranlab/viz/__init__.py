"""Figures and reports."""

from ranlab.viz.kpi_plots import (
    plot_fairness_tradeoff,
    plot_kpi_vs_axis,
    plot_sinr_cdf,
    plot_throughput_cdf,
    save_all_figures,
)
from ranlab.viz.network_plots import plot_deployment
from ranlab.viz.report import build_report
from ranlab.viz.style import POLICY_COLOURS, apply_style, colour_for

__all__ = [
    "POLICY_COLOURS",
    "apply_style",
    "build_report",
    "colour_for",
    "plot_deployment",
    "plot_fairness_tradeoff",
    "plot_kpi_vs_axis",
    "plot_sinr_cdf",
    "plot_throughput_cdf",
    "save_all_figures",
]
