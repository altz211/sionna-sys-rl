"""Network-geometry figures.

These make the deployment visible.  Their purpose is diagnostic rather than
decorative: a wrongly-oriented sector, a UE drop that clusters at the origin
or a serving-cell assignment that ignores the antenna pattern are all obvious
in a picture and nearly invisible in a KPI table.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from ranlab.scenario.layout import Deployment
from ranlab.viz.style import apply_style

__all__ = ["plot_deployment"]


def plot_deployment(
    deployment: Deployment,
    output_path: Path | str,
    sinr_db: np.ndarray | None = None,
    title: str = "Deployment layout",
) -> Path:
    """Plot sites, sector boresights, UEs and their serving-cell association.

    When ``sinr_db`` is supplied the UEs are coloured by SINR, which turns the
    plot into a coverage map and makes cell-edge regions immediately visible.
    """
    apply_style()
    fig, ax = plt.subplots(figsize=(6.4, 6.0))

    # UE-to-serving-cell association lines.
    serving_xy = deployment.cell_xy[deployment.serving_cell]
    for ue_xy, cell_xy in zip(deployment.ue_xy, serving_xy, strict=True):
        ax.plot(
            [ue_xy[0], cell_xy[0]], [ue_xy[1], cell_xy[1]],
            color="#CCCCCC", linewidth=0.4, zorder=1,
        )

    if sinr_db is not None:
        scatter = ax.scatter(
            deployment.ue_xy[:, 0], deployment.ue_xy[:, 1],
            c=np.asarray(sinr_db), cmap="viridis", s=14, zorder=3,
        )
        fig.colorbar(scatter, ax=ax, label="Mean SINR (dB)", shrink=0.82)
    else:
        ax.scatter(
            deployment.ue_xy[:, 0], deployment.ue_xy[:, 1],
            s=12, color="#0072B2", alpha=0.7, zorder=3, label="UE",
        )

    # Sites and sector boresights.
    ax.scatter(
        deployment.site_xy[:, 0], deployment.site_xy[:, 1],
        marker="^", s=120, color="#D55E00", edgecolor="black",
        linewidth=0.6, zorder=5, label="Site",
    )

    arrow_length = 0.18 * float(np.ptp(deployment.site_xy[:, 0]) or 200.0)
    for cell_xy, boresight in zip(
        deployment.cell_xy, deployment.cell_boresight_rad, strict=True
    ):
        ax.annotate(
            "",
            xy=(
                cell_xy[0] + arrow_length * np.cos(boresight),
                cell_xy[1] + arrow_length * np.sin(boresight),
            ),
            xytext=(cell_xy[0], cell_xy[1]),
            arrowprops={"arrowstyle": "->", "color": "#D55E00", "linewidth": 1.1},
            zorder=4,
        )

    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title(title)
    ax.set_aspect("equal", adjustable="box")
    ax.legend(loc="upper right")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path)
    plt.close(fig)
    return output_path
