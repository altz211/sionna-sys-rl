"""Matplotlib styling shared by every figure.

A consistent, restrained style is a small thing that makes a repository read
as considered rather than assembled.  Everything here is deliberate: a
colour-blind-safe qualitative palette, a fixed policy-to-colour mapping so a
scheduler keeps its colour across every figure in the report, and muted
gridlines that stay behind the data.
"""

from __future__ import annotations

import matplotlib as mpl
import matplotlib.pyplot as plt

__all__ = ["POLICY_COLOURS", "apply_style", "colour_for"]

#: Okabe-Ito qualitative palette: distinguishable under all common forms of
#: colour vision deficiency and in greyscale print.
_PALETTE = [
    "#0072B2",  # blue
    "#D55E00",  # vermillion
    "#009E73",  # bluish green
    "#CC79A7",  # reddish purple
    "#E69F00",  # orange
    "#56B4E9",  # sky blue
    "#F0E442",  # yellow
    "#000000",  # black
]

#: Fixed mapping so a policy keeps one colour across the whole report.
POLICY_COLOURS: dict[str, str] = {
    "Round Robin": _PALETTE[0],
    "Proportional Fair": _PALETTE[2],
    "Max C/I": _PALETTE[1],
    "Learned (RL)": _PALETTE[3],
}

_RC = {
    "figure.figsize": (7.0, 4.4),
    "figure.dpi": 120,
    "savefig.dpi": 200,
    "savefig.bbox": "tight",
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.titleweight": "semibold",
    "axes.labelsize": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "axes.axisbelow": True,
    "grid.color": "#D9D9D9",
    "grid.linewidth": 0.6,
    "legend.frameon": False,
    "legend.fontsize": 9,
    "lines.linewidth": 1.9,
    "lines.markersize": 5,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "xtick.direction": "out",
    "ytick.direction": "out",
}


def apply_style() -> None:
    """Install the RAN-LAB plotting style for the current session."""
    mpl.rcParams.update(_RC)
    plt.rcParams["axes.prop_cycle"] = mpl.cycler(color=_PALETTE)


def colour_for(label: str, fallback_index: int = 0) -> str:
    """Return the fixed colour for a policy label, or a palette fallback."""
    return POLICY_COLOURS.get(label, _PALETTE[fallback_index % len(_PALETTE)])
