"""Self-contained HTML experiment report.

The report is generated from the results, never hand-edited.  It carries the
provenance banner — code revision, seed count, working-tree cleanliness — at
the top rather than in a footnote, so a reader learns immediately whether the
numbers below it are trustworthy.
"""

from __future__ import annotations

import base64
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from jinja2 import Environment, PackageLoader, select_autoescape

__all__ = ["build_report"]


def _embed_png(path: Path) -> str:
    """Inline a PNG as a data URI so the report is a single portable file."""
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def _provenance_summary(run_df: pd.DataFrame) -> dict[str, Any]:
    commits = sorted({c for c in run_df.get("git_commit", pd.Series(dtype=str)).dropna()})
    dirty_flags = run_df.get("git_dirty", pd.Series(dtype=bool)).dropna()

    warnings: list[str] = []
    if not commits:
        warnings.append(
            "No git revision was recorded for these runs, so the results cannot be "
            "tied to a code version."
        )
    if len(commits) > 1:
        warnings.append(
            f"Results span {len(commits)} different code revisions; they are not "
            "directly comparable."
        )
    if len(dirty_flags) and bool(dirty_flags.any()):
        warnings.append(
            "At least one run was produced from a dirty working tree; its exact code "
            "state is not recoverable."
        )

    return {
        "commits": commits,
        "n_runs": int(len(run_df)),
        "n_conditions": int(run_df["condition_hash"].nunique()),
        "n_seeds": int(run_df["seed"].nunique()),
        "warnings": warnings,
    }


def build_report(
    run_df: pd.DataFrame,
    summary_table: pd.DataFrame,
    figures: list[Path],
    output_path: Path | str,
    title: str = "RAN-LAB experiment report",
    description: str = "",
    caveats: list[str] | None = None,
) -> Path:
    """Render the HTML report for a completed experiment."""
    env = Environment(
        loader=PackageLoader("ranlab.viz", "templates"),
        autoescape=select_autoescape(["html"]),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    template = env.get_template("report.html.j2")

    html = template.render(
        title=title,
        description=description,
        generated_utc=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        provenance=_provenance_summary(run_df),
        summary_html=summary_table.to_html(
            index=False, float_format=lambda v: f"{v:,.3f}", border=0,
            classes="summary", justify="left",
        ),
        figures=[
            {"name": p.stem.replace("_", " ").title(), "data_uri": _embed_png(p)}
            for p in figures
            if p.exists()
        ],
        caveats=caveats or [],
    )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    return output_path
