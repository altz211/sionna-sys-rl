"""KPI figures.

The figure set is deliberately small and each plot answers one question.
The throughput CDF comes first because it is the canonical system-level
figure: it shows the whole distribution, with the 5th-percentile cell-edge
point marked, rather than collapsing the comparison to a single mean that
cannot distinguish "everyone improved" from "the median improved while the
tail collapsed".
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ranlab.viz.style import apply_style, colour_for

__all__ = [
    "plot_fairness_tradeoff",
    "plot_kpi_vs_axis",
    "plot_sinr_cdf",
    "plot_throughput_cdf",
    "save_all_figures",
]

_MBPS = 1e6


def _ecdf(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = np.sort(np.asarray(values, dtype=np.float64))
    y = np.arange(1, x.size + 1) / x.size
    return x, y


def plot_throughput_cdf(ue_df: pd.DataFrame, output_path: Path | str) -> Path:
    """Per-UE throughput CDF, one curve per policy, with the 5th percentile marked."""
    apply_style()
    fig, ax = plt.subplots()

    for idx, (policy, group) in enumerate(ue_df.groupby("scheduler", sort=False)):
        values = group["throughput_bps"].to_numpy() / _MBPS
        x, y = _ecdf(values)
        colour = colour_for(str(policy), idx)
        ax.plot(x, y, label=str(policy), color=colour)
        p5 = float(np.percentile(values, 5))
        ax.plot([p5], [0.05], marker="o", color=colour, markersize=6, zorder=5)

    ax.axhline(0.05, color="#999999", linestyle=":", linewidth=1.0, zorder=1)
    ax.text(
        0.99, 0.065, "5th percentile (cell edge)",
        transform=ax.get_yaxis_transform(), ha="right", va="bottom",
        fontsize=8, color="#666666",
    )
    ax.set_xlabel("Per-UE throughput (Mbps)")
    ax.set_ylabel("Empirical CDF")
    ax.set_title("Per-UE throughput distribution")
    ax.set_ylim(0, 1)
    ax.set_xlim(left=0)
    ax.legend(title="Policy")

    return _save(fig, output_path)


def plot_sinr_cdf(ue_df: pd.DataFrame, output_path: Path | str) -> Path:
    """Wideband SINR CDF — the link-budget sanity check.

    This is the figure to compare against a published reference distribution:
    if the SINR CDF is wrong, every KPI downstream of it is wrong too.
    """
    apply_style()
    fig, ax = plt.subplots()

    for idx, (policy, group) in enumerate(ue_df.groupby("scheduler", sort=False)):
        x, y = _ecdf(group["mean_sinr_db"].to_numpy())
        ax.plot(x, y, label=str(policy), color=colour_for(str(policy), idx))

    ax.set_xlabel("Mean wideband SINR (dB)")
    ax.set_ylabel("Empirical CDF")
    ax.set_title("SINR distribution")
    ax.set_ylim(0, 1)
    ax.legend(title="Policy")

    return _save(fig, output_path)


def plot_fairness_tradeoff(run_df: pd.DataFrame, output_path: Path | str) -> Path:
    """Aggregate throughput against Jain fairness: the trade-off region.

    Each policy occupies a point; the classical baselines bracket the region a
    learned policy has to improve on.  A policy that moves up and to the right
    dominates; one that moves up and to the left has only traded fairness for
    throughput, which is not an improvement.
    """
    apply_style()
    fig, ax = plt.subplots()

    grouped = run_df.groupby("scheduler", sort=False)
    for idx, (policy, group) in enumerate(grouped):
        x = group["jain_fairness"].to_numpy()
        y = group["cell_throughput_bps"].to_numpy() / _MBPS
        colour = colour_for(str(policy), idx)
        ax.scatter(x, y, s=45, color=colour, label=str(policy), zorder=3, edgecolor="white")
        ax.scatter(
            [np.mean(x)], [np.mean(y)],
            s=170, color=colour, marker="X", zorder=4, edgecolor="white", linewidth=1.2,
        )

    ax.set_xlabel("Jain fairness index (throughput)")
    ax.set_ylabel("Cell throughput (Mbps)")
    ax.set_title("Throughput / fairness trade-off")
    ax.legend(title="Policy")

    return _save(fig, output_path)


def plot_kpi_vs_axis(
    agg_df: pd.DataFrame,
    axis: str,
    metric: str,
    output_path: Path | str,
    ylabel: str | None = None,
    xlabel: str | None = None,
    scale: float = 1.0,
) -> Path:
    """A KPI against one sweep axis, with confidence bands across seeds.

    Expects the output of :func:`ranlab.metrics.aggregate_over_seeds`, i.e.
    columns ``<metric>_mean``, ``<metric>_ci_low`` and ``<metric>_ci_high``.
    """
    apply_style()
    fig, ax = plt.subplots()

    mean_col, low_col, high_col = f"{metric}_mean", f"{metric}_ci_low", f"{metric}_ci_high"
    for idx, (policy, group) in enumerate(agg_df.groupby("scheduler", sort=False)):
        group = group.sort_values(axis)
        x = group[axis].to_numpy()
        colour = colour_for(str(policy), idx)
        ax.plot(x, group[mean_col].to_numpy() / scale, marker="o",
                label=str(policy), color=colour)
        ax.fill_between(
            x,
            group[low_col].to_numpy() / scale,
            group[high_col].to_numpy() / scale,
            color=colour, alpha=0.18, linewidth=0,
        )

    ax.set_xlabel(xlabel or axis.replace("_", " "))
    ax.set_ylabel(ylabel or metric.replace("_", " "))
    ax.set_title(f"{ylabel or metric} versus {xlabel or axis.replace('_', ' ')}")
    ax.legend(title="Policy")

    return _save(fig, output_path)


def _save(fig: plt.Figure, output_path: Path | str) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path)
    plt.close(fig)
    return output_path


def save_all_figures(
    ue_df: pd.DataFrame, run_df: pd.DataFrame, figures_dir: Path | str
) -> list[Path]:
    """Generate the standard figure set for a completed experiment."""
    figures_dir = Path(figures_dir)
    paths = [
        plot_throughput_cdf(ue_df, figures_dir / "throughput_cdf.png"),
        plot_sinr_cdf(ue_df, figures_dir / "sinr_cdf.png"),
        plot_fairness_tradeoff(run_df, figures_dir / "fairness_tradeoff.png"),
    ]
    return paths
