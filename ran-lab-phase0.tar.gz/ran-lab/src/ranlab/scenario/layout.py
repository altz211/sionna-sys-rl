"""Deployment geometry: hexagonal site layout and UE dropping.

The hexagonal grid follows the standard 3GPP evaluation layout: sites on a
triangular lattice at the configured inter-site distance, each split into
three 120-degree sectors.  One "ring" of neighbours around a centre site gives
7 sites (21 cells); two rings give 19 sites (57 cells).

Wrap-around is supported because without it the outer cells of a finite grid
see less interference than the interior, which biases every interference
statistic in the study.  The standard fix is a toroidal topology: distances
are computed to the nearest of the layout's periodic images.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ranlab.config import ScenarioConfig

__all__ = ["Deployment", "build_deployment", "hex_site_positions"]

_SQRT3 = np.sqrt(3.0)


def hex_site_positions(n_rings: int, isd_m: float) -> np.ndarray:
    """Return ``(n_sites, 2)`` site coordinates on a triangular lattice.

    Uses axial hex coordinates, so the result is exact rather than an
    approximation built from nested rings.
    """
    positions = []
    for q in range(-n_rings, n_rings + 1):
        r_low = max(-n_rings, -q - n_rings)
        r_high = min(n_rings, -q + n_rings)
        for r in range(r_low, r_high + 1):
            x = isd_m * (q + r / 2.0)
            y = isd_m * (_SQRT3 / 2.0) * r
            positions.append((x, y))
    return np.asarray(positions, dtype=np.float64)


@dataclass(frozen=True)
class Deployment:
    """A realised network deployment with base stations and dropped UEs."""

    site_xy: np.ndarray  # (n_sites, 2)
    cell_xy: np.ndarray  # (n_cells, 2) — co-located with their site
    cell_site_id: np.ndarray  # (n_cells,)
    cell_boresight_rad: np.ndarray  # (n_cells,)
    ue_xy: np.ndarray  # (n_ue, 2)
    serving_cell: np.ndarray  # (n_ue,)
    wrap_period: tuple[float, float] | None

    @property
    def n_sites(self) -> int:
        return int(self.site_xy.shape[0])

    @property
    def n_cells(self) -> int:
        return int(self.cell_xy.shape[0])

    @property
    def n_ue(self) -> int:
        return int(self.ue_xy.shape[0])

    def distance_matrix(self) -> np.ndarray:
        """``(n_ue, n_cells)`` 2-D distances, respecting wrap-around."""
        delta = self.ue_xy[:, None, :] - self.cell_xy[None, :, :]
        if self.wrap_period is not None:
            period = np.asarray(self.wrap_period, dtype=np.float64)
            delta = delta - period * np.round(delta / period)
        return np.linalg.norm(delta, axis=-1)

    def bearing_matrix(self) -> np.ndarray:
        """``(n_ue, n_cells)`` bearings from cell to UE, in radians."""
        delta = self.ue_xy[:, None, :] - self.cell_xy[None, :, :]
        if self.wrap_period is not None:
            period = np.asarray(self.wrap_period, dtype=np.float64)
            delta = delta - period * np.round(delta / period)
        return np.arctan2(delta[..., 1], delta[..., 0])


def _sector_boresights(sectors_per_site: int) -> np.ndarray:
    """Boresight angles for the sectors of one site.

    Three-sector sites point at 30, 150 and 270 degrees, the 3GPP convention.
    """
    if sectors_per_site == 1:
        return np.asarray([0.0])
    step = 2.0 * np.pi / sectors_per_site
    offset = np.pi / 6.0 if sectors_per_site == 3 else 0.0
    return offset + step * np.arange(sectors_per_site)


def build_deployment(
    scenario: ScenarioConfig,
    rng: np.random.Generator,
) -> Deployment:
    """Build the site grid, drop UEs uniformly, and assign serving cells.

    UEs are dropped uniformly over the bounding area of the layout rather than
    per-cell, so that UE density varies naturally with geometry instead of
    being forced equal in every cell.  Serving-cell assignment is by minimum
    path loss, approximated here by the antenna-gain-weighted distance.
    """
    if scenario.layout != "hex_grid":
        raise NotImplementedError(
            "only layout='hex_grid' is implemented; 'real_topology' arrives with the "
            "OpenCelliD experiment in Phase 5"
        )

    site_xy = hex_site_positions(scenario.n_rings, scenario.isd_m)
    n_sites = site_xy.shape[0]

    boresights = _sector_boresights(scenario.sectors_per_site)
    cell_xy = np.repeat(site_xy, scenario.sectors_per_site, axis=0)
    cell_site_id = np.repeat(np.arange(n_sites), scenario.sectors_per_site)
    cell_boresight = np.tile(boresights, n_sites)
    n_cells = cell_xy.shape[0]

    n_ue = n_cells * scenario.n_ue_per_cell

    # Bounding region: the hexagonal layout's circumscribed square.
    extent = scenario.isd_m * (scenario.n_rings + 0.5)
    wrap_period: tuple[float, float] | None = None
    if scenario.wrap_around:
        wrap_period = (2.0 * extent, 2.0 * extent)

    ue_xy = rng.uniform(-extent, extent, size=(n_ue, 2))

    # Enforce the minimum BS-UE separation by re-dropping offending UEs.
    for _ in range(100):
        delta = ue_xy[:, None, :] - cell_xy[None, :, :]
        if wrap_period is not None:
            period = np.asarray(wrap_period, dtype=np.float64)
            delta = delta - period * np.round(delta / period)
        distance = np.linalg.norm(delta, axis=-1)
        too_close = distance.min(axis=1) < scenario.min_bs_ue_distance_m
        if not np.any(too_close):
            break
        ue_xy[too_close] = rng.uniform(-extent, extent, size=(int(too_close.sum()), 2))

    deployment = Deployment(
        site_xy=site_xy,
        cell_xy=cell_xy,
        cell_site_id=cell_site_id,
        cell_boresight_rad=cell_boresight,
        ue_xy=ue_xy,
        serving_cell=np.zeros(n_ue, dtype=np.int32),
        wrap_period=wrap_period,
    )

    # Serving cell = strongest received power, using distance and sector gain.
    distance = np.maximum(deployment.distance_matrix(), 1.0)
    bearing = deployment.bearing_matrix()
    angle_off_boresight = np.angle(np.exp(1j * (bearing - cell_boresight[None, :])))
    sector_gain_db = _sector_antenna_gain_db(angle_off_boresight, scenario.sectors_per_site)
    proxy_rsrp_db = sector_gain_db - 20.0 * np.log10(distance)
    serving = np.argmax(proxy_rsrp_db, axis=1).astype(np.int32)

    return Deployment(
        site_xy=site_xy,
        cell_xy=cell_xy,
        cell_site_id=cell_site_id,
        cell_boresight_rad=cell_boresight,
        ue_xy=ue_xy,
        serving_cell=serving,
        wrap_period=wrap_period,
    )


def _sector_antenna_gain_db(
    angle_off_boresight_rad: np.ndarray, sectors_per_site: int
) -> np.ndarray:
    """3GPP TR 38.901 Table 7.3-1 horizontal antenna pattern.

    ``A(phi) = -min(12 (phi / phi_3dB)^2, A_max)`` with a 65-degree 3 dB
    beamwidth and 30 dB front-to-back ratio.  Omnidirectional when the site
    has a single sector.
    """
    if sectors_per_site == 1:
        return np.zeros_like(angle_off_boresight_rad)
    phi_deg = np.degrees(angle_off_boresight_rad)
    phi_3db, a_max = 65.0, 30.0
    return -np.minimum(12.0 * (phi_deg / phi_3db) ** 2, a_max)
