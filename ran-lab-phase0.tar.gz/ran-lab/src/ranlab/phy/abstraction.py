"""Link-to-system abstraction: mapping SINR onto a delivered bit rate.

A system-level simulator does not simulate the waveform.  It maps the
post-equaliser SINR onto a transport-block error probability using curves
measured from a link-level simulator, then applies link adaptation and HARQ.

Phase 0 provides the two bracketing approximations:

``shannon``
    The unconstrained Shannon bound, capped at the peak spectral efficiency of
    the MCS table.  Optimistic: no modulation quantisation, no coding loss.

``stub``
    Shannon with a fixed implementation-loss margin and an explicit SINR
    threshold below which the link is declared in outage.  Still a
    placeholder, but it produces the qualitative outage behaviour that makes
    scheduler comparisons meaningful.

Phase 1 adds ``eesm``, backed by tabulated NR link-level curves, and the
:mod:`tests/validation` suite checks it against a published reference.
"""

from __future__ import annotations

import numpy as np

from ranlab.config import ChannelConfig, PhyConfig

__all__ = ["effective_bler", "spectral_efficiency_from_sinr", "achievable_rate_bps"]

#: Implementation-loss margin applied to the Shannon bound, in dB. Represents
#: the aggregate cost of practical coding, estimation and quantisation.
_IMPLEMENTATION_LOSS_DB = 3.0

#: SINR below which the placeholder model declares the link unusable.
_OUTAGE_THRESHOLD_DB = -6.0


def spectral_efficiency_from_sinr(sinr_db: np.ndarray, phy: PhyConfig) -> np.ndarray:
    """Spectral efficiency in bits/s/Hz for a given SINR."""
    sinr_db = np.asarray(sinr_db, dtype=np.float64)

    if phy.abstraction == "shannon":
        effective_db = sinr_db
        usable = np.ones_like(sinr_db, dtype=bool)
    elif phy.abstraction == "stub":
        effective_db = sinr_db - _IMPLEMENTATION_LOSS_DB
        usable = sinr_db >= _OUTAGE_THRESHOLD_DB
    elif phy.abstraction == "eesm":  # pragma: no cover - Phase 1
        raise NotImplementedError(
            "EESM abstraction arrives in Phase 1 together with the NR link-level curves"
        )
    else:  # pragma: no cover - guarded by the config schema
        raise ValueError(f"unknown PHY abstraction: {phy.abstraction}")

    sinr_linear = 10.0 ** (effective_db / 10.0)
    se = np.log2(1.0 + sinr_linear)
    se = np.minimum(se, phy.spectral_efficiency_cap_bps_hz)
    return np.where(usable, se, 0.0)


def effective_bler(sinr_db: np.ndarray, phy: PhyConfig) -> np.ndarray:
    """Residual block-error rate after link adaptation.

    Link adaptation targets ``phy.target_bler`` by construction, so in this
    placeholder the residual BLER is the target wherever the link is usable
    and 1.0 where it is in outage.  The real model derives BLER from the
    selected MCS and the effective SINR, and HARQ then reduces it further.
    """
    sinr_db = np.asarray(sinr_db, dtype=np.float64)
    in_outage = sinr_db < _OUTAGE_THRESHOLD_DB
    return np.where(in_outage, 1.0, phy.target_bler)


def achievable_rate_bps(
    sinr_db: np.ndarray, phy: PhyConfig, channel: ChannelConfig
) -> np.ndarray:
    """Rate a UE would achieve if granted the full cell bandwidth this slot.

    Scaled by ``(1 - target_bler)`` so the reported rate is the expected
    *successfully delivered* rate rather than the attempted rate.
    """
    se = spectral_efficiency_from_sinr(sinr_db, phy)
    return se * channel.bandwidth_hz * (1.0 - phy.target_bler)
