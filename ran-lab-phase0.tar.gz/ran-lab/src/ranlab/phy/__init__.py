"""Physical-layer abstraction: SINR to delivered rate."""

from ranlab.phy.abstraction import (
    achievable_rate_bps,
    effective_bler,
    spectral_efficiency_from_sinr,
)

__all__ = ["achievable_rate_bps", "effective_bler", "spectral_efficiency_from_sinr"]
