"""Key performance indicators and statistical aggregation."""

from ranlab.metrics.kpis import (
    energy_per_bit_nj,
    jain_fairness,
    spectral_efficiency,
    summarise_throughput,
    total_energy_j,
)
from ranlab.metrics.statistics import (
    aggregate_over_seeds,
    bootstrap_ci,
    cohens_d,
    compare_conditions,
    mean_ci,
)

__all__ = [
    "aggregate_over_seeds",
    "bootstrap_ci",
    "cohens_d",
    "compare_conditions",
    "energy_per_bit_nj",
    "jain_fairness",
    "mean_ci",
    "spectral_efficiency",
    "summarise_throughput",
    "total_energy_j",
]
