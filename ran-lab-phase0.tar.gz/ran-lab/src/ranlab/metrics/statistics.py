"""Statistical aggregation across random seeds.

A single simulation run is one draw from a stochastic process.  Reporting it
as a result is the most common methodological error in simulation studies, and
it is the reason two implementations of the same scheduler can appear to
disagree.  Every KPI in this repository is therefore reported as a mean over
independent seeds with a confidence interval, and policy comparisons are
accompanied by an effect size and a paired test rather than a bare difference
of means.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats

__all__ = [
    "aggregate_over_seeds",
    "bootstrap_ci",
    "cohens_d",
    "compare_conditions",
    "mean_ci",
]


def bootstrap_ci(
    values: np.ndarray,
    confidence: float = 0.95,
    n_resamples: int = 10_000,
    seed: int = 0,
) -> tuple[float, float]:
    """Percentile bootstrap confidence interval for the mean.

    Preferred over a normal-theory interval because KPI distributions across
    seeds are small-sample and frequently skewed, especially tail statistics
    such as the 5th-percentile throughput.
    """
    x = np.asarray(values, dtype=np.float64)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return (float("nan"), float("nan"))
    if x.size == 1:
        return (float(x[0]), float(x[0]))
    rng = np.random.default_rng(seed)
    means = rng.choice(x, size=(n_resamples, x.size), replace=True).mean(axis=1)
    alpha = (1.0 - confidence) / 2.0
    return (
        float(np.percentile(means, 100 * alpha)),
        float(np.percentile(means, 100 * (1.0 - alpha))),
    )


def mean_ci(
    values: np.ndarray, confidence: float = 0.95, method: str = "bootstrap", seed: int = 0
) -> dict[str, float]:
    """Mean, standard deviation, sample size and confidence interval."""
    x = np.asarray(values, dtype=np.float64)
    x = x[np.isfinite(x)]
    n = int(x.size)
    if n == 0:
        return {"mean": np.nan, "std": np.nan, "n": 0, "ci_low": np.nan, "ci_high": np.nan}

    mean = float(np.mean(x))
    std = float(np.std(x, ddof=1)) if n > 1 else 0.0

    if method == "bootstrap":
        low, high = bootstrap_ci(x, confidence=confidence, seed=seed)
    elif method == "t":
        if n > 1:
            half = stats.t.ppf(0.5 + confidence / 2.0, df=n - 1) * std / np.sqrt(n)
        else:
            half = 0.0
        low, high = mean - half, mean + half
    else:
        raise ValueError("method must be 'bootstrap' or 't'")

    return {"mean": mean, "std": std, "n": n, "ci_low": float(low), "ci_high": float(high)}


def aggregate_over_seeds(
    df: pd.DataFrame,
    metrics: list[str],
    group_by: list[str] | None = None,
    confidence: float = 0.95,
) -> pd.DataFrame:
    """Collapse per-seed runs into per-condition means with confidence intervals.

    Grouping defaults to ``condition_hash`` plus the human-readable condition
    descriptors, which is exactly the grouping the condition hash was designed
    to make unambiguous.
    """
    if group_by is None:
        group_by = [
            c
            for c in ("condition_hash", "scheduler", "n_ue_per_cell", "ue_speed_kmph",
                      "offered_load_scale", "scenario", "channel_model", "traffic_model")
            if c in df.columns
        ]

    missing = [m for m in metrics if m not in df.columns]
    if missing:
        raise KeyError(f"metrics not present in results table: {missing}")

    records = []
    for keys, group in df.groupby(group_by, dropna=False, sort=False):
        key_tuple = keys if isinstance(keys, tuple) else (keys,)
        record: dict[str, object] = dict(zip(group_by, key_tuple, strict=True))
        record["n_seeds"] = int(len(group))
        for metric in metrics:
            summary = mean_ci(group[metric].to_numpy(), confidence=confidence)
            record[f"{metric}_mean"] = summary["mean"]
            record[f"{metric}_std"] = summary["std"]
            record[f"{metric}_ci_low"] = summary["ci_low"]
            record[f"{metric}_ci_high"] = summary["ci_high"]
        records.append(record)

    return pd.DataFrame.from_records(records)


def cohens_d(a: np.ndarray, b: np.ndarray) -> float:
    """Standardised effect size between two samples (pooled standard deviation).

    Reported alongside p-values because with enough seeds any difference
    becomes statistically significant; the question that matters is whether it
    is large enough to care about.
    """
    x, y = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    x, y = x[np.isfinite(x)], y[np.isfinite(y)]
    if x.size < 2 or y.size < 2:
        return float("nan")
    pooled_var = ((x.size - 1) * np.var(x, ddof=1) + (y.size - 1) * np.var(y, ddof=1)) / (
        x.size + y.size - 2
    )
    if pooled_var <= 0:
        return float("nan")
    return float((np.mean(x) - np.mean(y)) / np.sqrt(pooled_var))


def compare_conditions(
    df: pd.DataFrame,
    metric: str,
    condition_col: str,
    baseline: str,
    candidate: str,
    paired_on: str = "seed",
) -> dict[str, float | str | bool]:
    """Compare two policies on one metric, seed-paired where possible.

    When both conditions were run on the same seeds, a paired test is used:
    it removes the seed-to-seed variance that is common to both policies and
    is therefore substantially more sensitive than an unpaired comparison.
    """
    base = df[df[condition_col] == baseline]
    cand = df[df[condition_col] == candidate]
    if base.empty or cand.empty:
        raise KeyError(f"no rows for '{baseline}' or '{candidate}' in column '{condition_col}'")

    paired = False
    if paired_on in df.columns:
        shared = sorted(set(base[paired_on]) & set(cand[paired_on]))
        if len(shared) >= 2:
            base = base.set_index(paired_on).loc[shared]
            cand = cand.set_index(paired_on).loc[shared]
            paired = True

    x = cand[metric].to_numpy(dtype=np.float64)
    y = base[metric].to_numpy(dtype=np.float64)

    if paired:
        statistic, p_value = stats.ttest_rel(x, y)
    else:
        statistic, p_value = stats.ttest_ind(x, y, equal_var=False)

    base_mean = float(np.mean(y))
    rel = float((np.mean(x) - base_mean) / base_mean * 100.0) if base_mean != 0 else float("nan")

    return {
        "metric": metric,
        "baseline": baseline,
        "candidate": candidate,
        "baseline_mean": base_mean,
        "candidate_mean": float(np.mean(x)),
        "absolute_delta": float(np.mean(x) - base_mean),
        "relative_delta_pct": rel,
        "cohens_d": cohens_d(x, y),
        "t_statistic": float(statistic),
        "p_value": float(p_value),
        "paired": paired,
        "n_pairs": int(min(x.size, y.size)),
    }
