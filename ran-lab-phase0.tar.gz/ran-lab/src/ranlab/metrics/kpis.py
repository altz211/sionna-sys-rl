"""Key performance indicators.

The KPI set follows standard system-level evaluation practice: the
*distribution* of per-UE throughput is the primary object, and the summary
statistics are drawn from it.  In particular the 5th-percentile UE throughput
is reported alongside the mean, because a scheduler that raises the mean while
starving the cell edge is not an improvement, and a mean-only comparison
cannot tell the two apart.
"""

from __future__ import annotations

import numpy as np

__all__ = [
    "energy_per_bit_nj",
    "jain_fairness",
    "spectral_efficiency",
    "summarise_throughput",
    "total_energy_j",
]


def jain_fairness(values: np.ndarray) -> float:
    r"""Jain's fairness index.

    .. math:: J(x) = \frac{(\sum_i x_i)^2}{n \sum_i x_i^2}

    Equals 1.0 under perfectly equal allocation and 1/n when one user takes
    everything, so it is directly comparable across different user counts.
    """
    x = np.asarray(values, dtype=np.float64)
    if x.size == 0:
        return float("nan")
    denom = x.size * np.sum(x**2)
    if denom <= 0:
        return float("nan")
    return float(np.sum(x) ** 2 / denom)


def summarise_throughput(throughput_bps: np.ndarray) -> dict[str, float]:
    """Summary statistics of the per-UE throughput distribution.

    The 5th percentile is the conventional cell-edge indicator in 3GPP
    evaluations; the 50th and 95th are reported so the shape of the
    distribution, not only its tail, is visible.
    """
    x = np.asarray(throughput_bps, dtype=np.float64)
    if x.size == 0:
        return {k: float("nan") for k in ("mean", "p5", "p50", "p95", "total")}
    return {
        "mean": float(np.mean(x)),
        "p5": float(np.percentile(x, 5)),
        "p50": float(np.percentile(x, 50)),
        "p95": float(np.percentile(x, 95)),
        "total": float(np.sum(x)),
    }


def spectral_efficiency(total_throughput_bps: float, bandwidth_hz: float, n_cells: int) -> float:
    """Area spectral efficiency in bits/s/Hz per cell."""
    if bandwidth_hz <= 0 or n_cells <= 0:
        return float("nan")
    return float(total_throughput_bps / (bandwidth_hz * n_cells))


def total_energy_j(
    n_cells: int,
    tx_power_dbm: float,
    circuit_power_w: float,
    pa_efficiency: float,
    duration_s: float,
) -> float:
    """Total radiated-plus-circuit energy consumed by the network.

    Uses the standard affine base-station power model: consumed power is a
    fixed circuit term plus the radiated power divided by the power-amplifier
    efficiency.
    """
    if pa_efficiency <= 0:
        return float("nan")
    tx_power_w = 10.0 ** ((tx_power_dbm - 30.0) / 10.0)
    per_cell_w = circuit_power_w + tx_power_w / pa_efficiency
    return float(n_cells * per_cell_w * duration_s)


def energy_per_bit_nj(total_energy_joules: float, total_bits: float) -> float:
    """Network energy per delivered bit, in nanojoules per bit.

    The headline energy-efficiency KPI: it rewards a policy that delivers the
    same traffic with less power, and penalises one that saves power by simply
    delivering less.
    """
    if total_bits <= 0:
        return float("nan")
    return float(total_energy_joules / total_bits * 1e9)
