"""Single-run simulation engine.

Orchestrates one experimental condition at one seed:

    deployment -> large-scale channel -> per-slot SINR -> PHY abstraction
               -> per-cell scheduling -> KPI accumulation -> result tables

Two design decisions are worth stating explicitly, because both are load-
bearing for the credibility of every result the repository produces.

**Reported CQI, not true SINR.**  Policies are given a *delayed, periodically
reported* rate estimate, never the instantaneous channel.  Handing a scheduler
the true channel is the single most common way a simulation study accidentally
reports an unachievable gain, and it is precisely the advantage a learned
policy would exploit if allowed to.

**Warm-up discarded.**  The proportional-fair throughput average needs time to
converge, and KPIs measured during that transient are not steady-state.  The
first ``sim.warmup_slots`` slots drive the state forward but contribute
nothing to the reported statistics.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import pandas as pd

from ranlab.channel.stub import compute_large_scale_gain, instantaneous_sinr_db
from ranlab.config import Config
from ranlab.mac import SchedulerContext, SlotState, build_scheduler
from ranlab.metrics.kpis import (
    energy_per_bit_nj,
    jain_fairness,
    spectral_efficiency,
    summarise_throughput,
    total_energy_j,
)
from ranlab.phy.abstraction import achievable_rate_bps, effective_bler
from ranlab.scenario.layout import build_deployment

__all__ = ["RunOutput", "simulate"]


@dataclass
class RunOutput:
    """Everything one simulation run produces."""

    ue_rows: pd.DataFrame
    run_row: dict[str, float | int]
    runtime_s: float


def _scheduler_kwargs(config: Config) -> dict[str, float]:
    """Translate the scheduler config block into policy constructor arguments."""
    if config.scheduler.algorithm == "proportional_fair":
        return {
            "alpha": config.scheduler.pf_alpha,
            "beta": config.scheduler.pf_beta,
        }
    return {}


def simulate(config: Config, seed: int | None = None) -> RunOutput:
    """Execute one simulation run and return its result tables.

    Parameters
    ----------
    config
        Fully resolved and validated configuration.
    seed
        Overrides ``config.run.seed`` when sweeping seeds.
    """
    started = time.perf_counter()
    seed = config.run.seed if seed is None else seed
    rng = np.random.default_rng(seed)

    # -- Deployment and slow-varying channel ------------------------------
    deployment = build_deployment(config.scenario, rng)
    large_scale = compute_large_scale_gain(deployment, config.scenario, config.channel, rng)

    n_ue = deployment.n_ue
    n_cells = deployment.n_cells
    slot_duration = config.sim.slot_duration_s
    total_slots = config.sim.warmup_slots + config.sim.n_slots

    # -- Per-cell scheduler instances --------------------------------------
    ue_of_cell = [np.flatnonzero(deployment.serving_cell == c) for c in range(n_cells)]
    schedulers = []
    for cell_id in range(n_cells):
        context = SchedulerContext(
            n_ue=int(ue_of_cell[cell_id].size),
            n_prb=config.channel.n_prb,
            slot_duration_s=slot_duration,
            bandwidth_hz=config.channel.bandwidth_hz,
        )
        schedulers.append(
            build_scheduler(
                config.scheduler.algorithm,
                context,
                np.random.default_rng(rng.integers(0, 2**32 - 1)),
                **_scheduler_kwargs(config),
            )
        )

    # -- Accumulators -------------------------------------------------------
    served_bits = np.zeros(n_ue, dtype=np.float64)
    scheduled_slots = np.zeros(n_ue, dtype=np.int64)
    sinr_accumulator: list[np.ndarray] = []
    bler_sum = np.zeros(n_ue, dtype=np.float64)
    bler_count = np.zeros(n_ue, dtype=np.float64)

    # PF throughput average, maintained by the engine so that every policy
    # observes an identically-defined state variable.
    ewma_window = max(1, config.scheduler.pf_ewma_window_slots)
    ewma_alpha = 1.0 / ewma_window
    avg_throughput = np.full(n_ue, 1.0, dtype=np.float64)

    # Reported CQI state: refreshed every cqi_report_period_slots and then
    # held, so the policy always acts on a stale estimate.
    reported_rate = np.zeros(n_ue, dtype=np.float64)
    report_period = max(1, config.phy.cqi_report_period_slots)

    # Full-buffer traffic: every UE always has data. Finite-buffer arrives with
    # the FTP Model 3 implementation in Phase 2.
    has_data = np.ones(n_ue, dtype=bool)

    # -- Main slot loop -----------------------------------------------------
    for slot in range(total_slots):
        sinr_db = instantaneous_sinr_db(
            large_scale, deployment, config.channel, config.power, rng
        )
        true_rate = achievable_rate_bps(sinr_db, config.phy, config.channel)

        if slot % report_period == 0:
            reported_rate = true_rate.copy()

        is_measured = slot >= config.sim.warmup_slots
        if is_measured:
            sinr_accumulator.append(sinr_db)

        for cell_id in range(n_cells):
            members = ue_of_cell[cell_id]
            if members.size == 0:
                continue

            state = SlotState(
                slot=slot,
                achievable_rate_bps=reported_rate[members],
                avg_throughput_bps=avg_throughput[members],
                has_data=has_data[members],
            )
            allocation = schedulers[cell_id].allocate(state)

            # Delivered rate uses the TRUE channel; the policy chose using the
            # reported one. The gap between them is CSI ageing, and it is the
            # mechanism that should erode channel-aware gains at high mobility.
            delivered = allocation * true_rate[members]
            bits = delivered * slot_duration

            if is_measured:
                served_bits[members] += bits
                scheduled_slots[members] += (allocation > 0).astype(np.int64)
                active = allocation > 0
                if np.any(active):
                    selected = members[active]
                    bler_sum[selected] += effective_bler(sinr_db[selected], config.phy)
                    bler_count[selected] += 1.0

            avg_throughput[members] = (
                1.0 - ewma_alpha
            ) * avg_throughput[members] + ewma_alpha * delivered

    runtime_s = time.perf_counter() - started

    # -- KPI computation ----------------------------------------------------
    measured_duration_s = config.sim.n_slots * slot_duration
    throughput_bps = served_bits / measured_duration_s

    sinr_matrix = np.asarray(sinr_accumulator)  # (n_measured_slots, n_ue)
    mean_sinr_db = sinr_matrix.mean(axis=0)
    p10_sinr_db = np.percentile(sinr_matrix, 10, axis=0)

    with np.errstate(invalid="ignore", divide="ignore"):
        per_ue_bler = np.where(bler_count > 0, bler_sum / np.maximum(bler_count, 1.0), np.nan)

    distance_to_serving = large_scale.distance_m[np.arange(n_ue), deployment.serving_cell]
    prb_share = scheduled_slots / float(config.sim.n_slots)
    per_ue_se = throughput_bps / config.channel.bandwidth_hz

    ue_rows = pd.DataFrame(
        {
            "ue_id": np.arange(n_ue, dtype=np.int32),
            "serving_cell_id": deployment.serving_cell.astype(np.int32),
            "x_m": deployment.ue_xy[:, 0].astype(np.float32),
            "y_m": deployment.ue_xy[:, 1].astype(np.float32),
            "distance_to_serving_m": distance_to_serving.astype(np.float32),
            "is_los": np.zeros(n_ue, dtype=bool),  # placeholder model has no LOS state
            "mean_sinr_db": mean_sinr_db.astype(np.float32),
            "p10_sinr_db": p10_sinr_db.astype(np.float32),
            "mean_wideband_sinr_db": mean_sinr_db.astype(np.float32),
            "throughput_bps": throughput_bps.astype(np.float64),
            "spectral_efficiency_bps_hz": per_ue_se.astype(np.float32),
            "bler": per_ue_bler.astype(np.float32),
            "mean_latency_ms": np.full(n_ue, np.nan, dtype=np.float32),
            "p95_latency_ms": np.full(n_ue, np.nan, dtype=np.float32),
            "served_bits": served_bits.astype(np.float64),
            "n_scheduled_slots": scheduled_slots.astype(np.int32),
            "prb_share": prb_share.astype(np.float32),
        }
    )

    summary = summarise_throughput(throughput_bps)
    energy_j = total_energy_j(
        n_cells=n_cells,
        tx_power_dbm=config.power.tx_power_dbm,
        circuit_power_w=config.power.circuit_power_w,
        pa_efficiency=config.power.pa_efficiency,
        duration_s=measured_duration_s,
    )

    run_row: dict[str, float | int] = {
        "n_ue": int(n_ue),
        "n_slots": int(config.sim.n_slots),
        "warmup_slots": int(config.sim.warmup_slots),
        "mean_ue_throughput_bps": summary["mean"],
        "p5_ue_throughput_bps": summary["p5"],
        "p50_ue_throughput_bps": summary["p50"],
        "p95_ue_throughput_bps": summary["p95"],
        "cell_throughput_bps": summary["total"] / n_cells,
        "spectral_efficiency_bps_hz": spectral_efficiency(
            summary["total"], config.channel.bandwidth_hz, n_cells
        ),
        "jain_fairness": jain_fairness(throughput_bps),
        "mean_bler": float(np.nanmean(per_ue_bler)) if np.any(bler_count > 0) else float("nan"),
        "mean_latency_ms": float("nan"),
        "p95_latency_ms": float("nan"),
        "energy_per_bit_nj": energy_per_bit_nj(energy_j, float(np.sum(served_bits))),
        "total_energy_j": energy_j,
        "sim_runtime_s": runtime_s,
    }

    return RunOutput(ue_rows=ue_rows, run_row=run_row, runtime_s=runtime_s)
