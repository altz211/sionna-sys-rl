"""Command-line interface.

Four verbs, matching the four things one does with an experiment::

    ranlab run      scheduler=proportional_fair run.seed=3   # one condition
    ranlab sweep    experiment=sweep_density                 # many conditions
    ranlab report   --experiment sweep_density               # figures + HTML
    ranlab config   scheduler=max_ci                         # inspect, run nothing

``config`` exists because the most common cause of a confusing result is a
configuration that is not what its author believed it to be.  Printing the
fully resolved tree, with its condition hash, is the cheapest possible check.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import yaml

from ranlab import __version__
from ranlab.config import ConfigError, compose, condition_hash, save_config, to_dict

logger = logging.getLogger("ranlab")

_EPILOG = """\
examples:
  ranlab run                                    run the default configuration
  ranlab run scheduler=max_ci sim=quick         override a config group
  ranlab run scenario.n_ue_per_cell=20          override a single value
  ranlab sweep experiment=sweep_density         run a declared sweep
  ranlab sweep experiment=sweep_load run=multiseed --workers 8
  ranlab report --experiment sweep_density      regenerate figures and HTML
  ranlab config scheduler=proportional_fair     print the resolved config
"""


def _configure_logging(verbosity: int) -> None:
    level = logging.WARNING if verbosity == 0 else logging.INFO if verbosity == 1 else logging.DEBUG
    logging.basicConfig(
        level=level,
        format="%(asctime)s  %(levelname)-7s  %(message)s",
        datefmt="%H:%M:%S",
    )


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "overrides", nargs="*",
        help="config overrides: 'group=option' or 'dotted.key=value'",
    )
    parser.add_argument("--config-dir", default="configs", help="configuration directory")
    parser.add_argument("--config-name", default="config", help="root config file stem")
    parser.add_argument("-v", "--verbose", action="count", default=1, help="increase verbosity")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ranlab",
        description="RAN-LAB: reproducible system-level RAN simulation.",
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"ranlab {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="execute a single simulation run")
    _add_common(run_parser)
    run_parser.add_argument("--output-dir", default=None, help="override run.output_dir")

    sweep_parser = subparsers.add_parser("sweep", help="execute a parameter sweep")
    _add_common(sweep_parser)
    sweep_parser.add_argument("--output-dir", default=None, help="override run.output_dir")
    sweep_parser.add_argument("--workers", type=int, default=None, help="parallel worker processes")
    sweep_parser.add_argument(
        "--dry-run", action="store_true", help="list the sweep points without running them"
    )

    report_parser = subparsers.add_parser("report", help="build figures and the HTML report")
    report_parser.add_argument("--results-dir", default="results/raw")
    report_parser.add_argument("--figures-dir", default="results/figures")
    report_parser.add_argument("--output", default="results/processed/report.html")
    report_parser.add_argument("--experiment", default=None, help="filter to one experiment")
    report_parser.add_argument("-v", "--verbose", action="count", default=1)

    config_parser = subparsers.add_parser("config", help="print the resolved configuration")
    _add_common(config_parser)

    return parser


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_config(args: argparse.Namespace) -> int:
    config = compose(args.config_dir, args.config_name, args.overrides)
    print(yaml.safe_dump(to_dict(config), sort_keys=True, default_flow_style=False))
    print(f"# condition_hash: {condition_hash(config)}")
    print(f"# cells: {config.scenario.n_cells}  "
          f"UEs: {config.scenario.n_cells * config.scenario.n_ue_per_cell}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    from ranlab.engine import simulate
    from ranlab.io import capture_provenance, write_run_results

    config = compose(args.config_dir, args.config_name, args.overrides)
    output_dir = args.output_dir or config.run.output_dir
    cond_hash = condition_hash(config)

    logger.info("condition %s | %s | %s", cond_hash, config.scenario.name, config.scheduler.name)

    provenance = capture_provenance(
        condition_hash=cond_hash, seed=config.run.seed, experiment=config.experiment.name
    )
    for warning in provenance.warnings():
        logger.warning("%s", warning)

    output = simulate(config)
    paths = write_run_results(
        output_dir=output_dir,
        config=config,
        provenance=provenance,
        ue_rows=output.ue_rows,
        run_row=output.run_row,
    )
    save_config(config, Path(output_dir) / f"{provenance.run_id}.config.yaml")

    row = output.run_row
    logger.info(
        "mean %.2f Mbps | cell-edge (p5) %.3f Mbps | Jain %.3f | %.1f s",
        row["mean_ue_throughput_bps"] / 1e6,
        row["p5_ue_throughput_bps"] / 1e6,
        row["jain_fairness"],
        output.runtime_s,
    )
    print(f"run_id={provenance.run_id}  condition={cond_hash}  -> {paths['run'].parent}")
    return 0


def cmd_sweep(args: argparse.Namespace) -> int:
    from ranlab.sweep import expand_sweep, run_sweep

    config = compose(args.config_dir, args.config_name, args.overrides)
    points = expand_sweep(config, args.overrides)

    if args.dry_run:
        print(f"experiment '{config.experiment.name}': {len(points)} run(s)")
        for point in points:
            print(f"  {point.label}")
        return 0

    records = run_sweep(
        config,
        config_dir=args.config_dir,
        config_name=args.config_name,
        base_overrides=args.overrides,
        output_dir=args.output_dir,
        n_workers=args.workers,
    )
    total_runtime = sum(r["runtime_s"] for r in records)
    print(
        f"completed {len(records)} run(s) of experiment '{config.experiment.name}' "
        f"in {total_runtime:.1f} s of simulation time"
    )
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    import pandas as pd

    from ranlab.io import load_results
    from ranlab.metrics import aggregate_over_seeds
    from ranlab.viz import build_report, save_all_figures

    run_df = load_results(args.results_dir, level="run")
    ue_df = load_results(args.results_dir, level="ue")

    if args.experiment:
        run_df = run_df[run_df["experiment"] == args.experiment]
        ue_df = ue_df[ue_df["experiment"] == args.experiment]
        if run_df.empty:
            logger.error("no results found for experiment '%s'", args.experiment)
            return 1

    metrics = [
        "mean_ue_throughput_bps",
        "p5_ue_throughput_bps",
        "cell_throughput_bps",
        "spectral_efficiency_bps_hz",
        "jain_fairness",
        "energy_per_bit_nj",
    ]
    aggregated = aggregate_over_seeds(run_df, metrics=metrics)

    summary = pd.DataFrame(
        {
            "Policy": aggregated["scheduler"],
            "Seeds": aggregated["n_seeds"],
            "Mean UE (Mbps)": aggregated["mean_ue_throughput_bps_mean"] / 1e6,
            "Cell edge p5 (Mbps)": aggregated["p5_ue_throughput_bps_mean"] / 1e6,
            "Cell (Mbps)": aggregated["cell_throughput_bps_mean"] / 1e6,
            "SE (bps/Hz)": aggregated["spectral_efficiency_bps_hz_mean"],
            "Jain": aggregated["jain_fairness_mean"],
            "Energy (nJ/bit)": aggregated["energy_per_bit_nj_mean"],
        }
    ).sort_values("Cell (Mbps)", ascending=False)

    figures = save_all_figures(ue_df, run_df, args.figures_dir)

    caveats: list[str] = []
    if (ue_df["phy_abstraction"] == "stub").any() or (ue_df["channel_model"] == "stub").any():
        caveats.append(
            "These runs use the Phase-0 placeholder channel and PHY abstraction. "
            "The absolute values are NOT calibrated against any 3GPP reference and "
            "must not be quoted as results; they demonstrate the pipeline only."
        )

    output = build_report(
        run_df=run_df,
        summary_table=summary,
        figures=figures,
        output_path=args.output,
        title="RAN-LAB experiment report",
        description=args.experiment or "All recorded experiments",
        caveats=caveats,
    )
    print(f"report -> {output}")
    print(f"figures -> {args.figures_dir}")
    return 0


_COMMANDS = {"run": cmd_run, "sweep": cmd_sweep, "report": cmd_report, "config": cmd_config}


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    _configure_logging(getattr(args, "verbose", 1))
    try:
        return _COMMANDS[args.command](args)
    except ConfigError as exc:
        logger.error("configuration error: %s", exc)
        return 2
    except FileNotFoundError as exc:
        logger.error("%s", exc)
        return 3
    except KeyboardInterrupt:  # pragma: no cover
        logger.warning("interrupted")
        return 130


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
