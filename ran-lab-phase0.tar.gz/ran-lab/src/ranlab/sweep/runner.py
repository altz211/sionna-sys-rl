"""Sweep expansion and parallel execution.

A sweep is the Cartesian product of the axes declared in
``configs/experiment/*.yaml``, crossed with the requested number of seeds.
Each resulting run is independent, so execution parallelises across processes
with no shared state.

Determinism is preserved under parallelism because each run's seed is derived
from its position in the expansion, not from a shared generator or from wall-
clock time.  Re-running a sweep with a different worker count therefore
produces bit-identical results — a property the integration tests check.
"""

from __future__ import annotations

import itertools
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ranlab.config import Config, ConfigError, compose, condition_hash
from ranlab.engine import simulate
from ranlab.io import capture_provenance, write_run_results

logger = logging.getLogger(__name__)

__all__ = ["SweepPoint", "expand_sweep", "run_point", "run_sweep"]


@dataclass(frozen=True)
class SweepPoint:
    """One executable unit of a sweep: a condition at a specific seed."""

    overrides: tuple[str, ...]
    seed: int
    index: int

    @property
    def label(self) -> str:
        return f"[{self.index}] " + " ".join(self.overrides) + f" seed={self.seed}"


def expand_sweep(
    config: Config,
    base_overrides: list[str] | None = None,
) -> list[SweepPoint]:
    """Expand an experiment configuration into its individual runs.

    Sweep keys are either a configuration-group name (``scheduler``), whose
    values name option files, or a dotted leaf (``scenario.n_ue_per_cell``),
    whose values are literals.  Both are re-applied as ordinary overrides, so
    a sweep point is reproducible from its override list alone.
    """
    base = list(base_overrides or [])
    axes = config.experiment.sweep

    if not axes:
        combinations: list[tuple[str, ...]] = [()]
    else:
        keys = list(axes)
        value_lists = [axes[k] for k in keys]
        for key, values in zip(keys, value_lists, strict=True):
            if not isinstance(values, list) or not values:
                raise ConfigError(
                    f"sweep axis '{key}' must be a non-empty list, got {values!r}"
                )
        combinations = [
            tuple(f"{k}={v}" for k, v in zip(keys, combo, strict=True))
            for combo in itertools.product(*value_lists)
        ]

    points: list[SweepPoint] = []
    index = 0
    for combo in combinations:
        for seed_offset in range(config.run.n_seeds):
            points.append(
                SweepPoint(
                    overrides=tuple(base) + combo,
                    seed=config.run.seed + seed_offset,
                    index=index,
                )
            )
            index += 1
    return points


def run_point(
    point: SweepPoint,
    config_dir: str,
    config_name: str,
    output_dir: str,
    experiment_name: str,
) -> dict[str, Any]:
    """Execute one sweep point and persist its results.

    Re-composes the configuration from its override list rather than receiving
    a config object, so that each worker process is fully self-contained and
    the run is reproducible from the recorded overrides alone.
    """
    config = compose(config_dir, config_name, list(point.overrides))
    cond_hash = condition_hash(config)

    provenance = capture_provenance(
        condition_hash=cond_hash,
        seed=point.seed,
        experiment=experiment_name,
        notes=" ".join(point.overrides) or None,
    )

    output = simulate(config, seed=point.seed)
    paths = write_run_results(
        output_dir=output_dir,
        config=config,
        provenance=provenance,
        ue_rows=output.ue_rows,
        run_row=output.run_row,
    )

    return {
        "run_id": provenance.run_id,
        "condition_hash": cond_hash,
        "seed": point.seed,
        "overrides": list(point.overrides),
        "runtime_s": output.runtime_s,
        "ue_path": str(paths["ue"]),
        "run_path": str(paths["run"]),
    }


def run_sweep(
    config: Config,
    config_dir: str = "configs",
    config_name: str = "config",
    base_overrides: list[str] | None = None,
    output_dir: str | Path | None = None,
    n_workers: int | None = None,
) -> list[dict[str, Any]]:
    """Expand and execute a sweep, returning one record per completed run."""
    points = expand_sweep(config, base_overrides)
    output_dir = str(output_dir or config.run.output_dir)
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    workers = int(n_workers or config.experiment.n_workers)
    experiment_name = config.experiment.name

    logger.info(
        "sweep '%s': %d run(s) across %d worker(s) -> %s",
        experiment_name,
        len(points),
        workers,
        output_dir,
    )

    if workers <= 1 or len(points) == 1:
        records = []
        for point in points:
            logger.info("running %s", point.label)
            records.append(
                run_point(point, config_dir, config_name, output_dir, experiment_name)
            )
        return records

    records = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(
                run_point, point, config_dir, config_name, output_dir, experiment_name
            ): point
            for point in points
        }
        for future in as_completed(futures):
            point = futures[future]
            try:
                records.append(future.result())
                logger.info("completed %s", point.label)
            except Exception:
                logger.exception("FAILED %s", point.label)
                raise

    # Restore deterministic ordering, which completion order does not preserve.
    records.sort(key=lambda r: (tuple(r["overrides"]), r["seed"]))
    return records
