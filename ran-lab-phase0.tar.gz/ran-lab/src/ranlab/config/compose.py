"""Configuration composition: YAML config groups, CLI overrides, condition hashing.

The composition semantics deliberately mirror Hydra's, because that idiom is
familiar in research codebases::

    ranlab run scheduler=proportional_fair scenario.n_ue_per_cell=20 run.seed=7

* ``group=option`` swaps in ``configs/<group>/<option>.yaml``.
* ``dotted.key=value`` overrides a single leaf, parsed as a YAML scalar.

RAN-LAB implements this directly on PyYAML and Pydantic rather than depending
on Hydra.  The reasons are deliberate: the resulting configuration is a typed,
frozen, strictly-validated Pydantic model rather than an untyped ``DictConfig``;
the dependency footprint of the experiment harness stays small enough that CI
installs and runs in seconds; and the composition logic is itself unit-tested
in ``tests/unit/test_config.py`` rather than trusted as a black box.
"""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

from ranlab.config.schema import Config

__all__ = [
    "ConfigError",
    "compose",
    "condition_hash",
    "load_yaml",
    "resolve_overrides",
    "save_config",
    "to_dict",
]

# Config blocks that describe *how a run was executed or swept* rather than
# *what physical condition was simulated*.  They are excluded from the
# condition hash so that repeated seeds of one condition share a hash and
# group together during analysis.
_NON_CONDITION_BLOCKS = frozenset({"run", "experiment"})

DEFAULT_CONFIG_DIR = Path("configs")
DEFAULT_CONFIG_NAME = "config"


class ConfigError(ValueError):
    """Raised when a configuration cannot be composed or validated."""


# ---------------------------------------------------------------------------
# YAML loading and merging
# ---------------------------------------------------------------------------


def load_yaml(path: Path) -> dict[str, Any]:
    """Load a YAML file into a dict, with a clear error if it is missing."""
    if not path.is_file():
        raise ConfigError(f"configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ConfigError(f"{path} must contain a YAML mapping at the top level")
    return data


def _deep_merge(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    """Recursively merge ``update`` into ``base``, returning a new dict."""
    merged = copy.deepcopy(base)
    for key, value in update.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _parse_scalar(raw: str) -> Any:
    """Parse an override value using YAML scalar rules.

    ``20`` -> int, ``3.5`` -> float, ``true`` -> bool, ``null`` -> None,
    ``[1,2,3]`` -> list, anything else -> str.
    """
    try:
        return yaml.safe_load(raw)
    except yaml.YAMLError:
        return raw


def _set_dotted(tree: dict[str, Any], dotted_key: str, value: Any) -> None:
    """Set ``tree['a']['b']['c'] = value`` from the key ``'a.b.c'``, in place."""
    parts = dotted_key.split(".")
    node = tree
    for part in parts[:-1]:
        if part not in node or not isinstance(node[part], dict):
            raise ConfigError(
                f"cannot apply override '{dotted_key}': '{part}' is not a configuration group"
            )
        node = node[part]
    leaf = parts[-1]
    if leaf not in node:
        raise ConfigError(
            f"cannot apply override '{dotted_key}': key '{leaf}' does not exist. "
            "Overrides may only modify declared configuration fields."
        )
    node[leaf] = value


# ---------------------------------------------------------------------------
# Composition
# ---------------------------------------------------------------------------


def resolve_overrides(overrides: list[str] | None) -> tuple[dict[str, str], dict[str, Any]]:
    """Split raw ``key=value`` strings into group selections and leaf overrides.

    Returns
    -------
    (group_selections, leaf_overrides)
        ``group_selections`` maps a config-group name to the option file to use.
        ``leaf_overrides`` maps a dotted key to its parsed value.
    """
    group_selections: dict[str, str] = {}
    leaf_overrides: dict[str, Any] = {}

    for item in overrides or []:
        if "=" not in item:
            raise ConfigError(
                f"malformed override '{item}'. Expected 'group=option' or 'dotted.key=value'."
            )
        key, _, raw_value = item.partition("=")
        key = key.strip()
        if not key:
            raise ConfigError(f"malformed override '{item}': empty key")
        if "." in key:
            leaf_overrides[key] = _parse_scalar(raw_value)
        else:
            group_selections[key] = raw_value.strip()

    return group_selections, leaf_overrides


def compose(
    config_dir: Path | str = DEFAULT_CONFIG_DIR,
    config_name: str = DEFAULT_CONFIG_NAME,
    overrides: list[str] | None = None,
) -> Config:
    """Compose, override and validate a full experiment configuration.

    Parameters
    ----------
    config_dir
        Directory containing ``<config_name>.yaml`` and the config-group
        subdirectories.
    config_name
        Root configuration file stem.
    overrides
        Command-line overrides, e.g. ``["scheduler=max_ci", "run.seed=3"]``.

    Returns
    -------
    Config
        A frozen, fully validated configuration.
    """
    config_dir = Path(config_dir)
    root = load_yaml(config_dir / f"{config_name}.yaml")

    defaults = root.pop("defaults", {})
    if not isinstance(defaults, dict):
        raise ConfigError(
            f"{config_name}.yaml: 'defaults' must be a mapping of group name to option name"
        )

    group_selections, leaf_overrides = resolve_overrides(overrides)

    unknown = set(group_selections) - set(defaults)
    if unknown:
        raise ConfigError(
            f"unknown configuration group(s): {sorted(unknown)}. "
            f"Available groups: {sorted(defaults)}"
        )
    selected = {**defaults, **group_selections}

    # 1. Start from the config-group option files.
    tree: dict[str, Any] = {}
    for group, option in selected.items():
        tree[group] = load_yaml(config_dir / group / f"{option}.yaml")

    # 2. Layer any inline blocks defined in the root file on top.
    tree = _deep_merge(tree, root)

    # 3. Apply leaf overrides last, so the command line always wins.
    for dotted_key, value in leaf_overrides.items():
        _set_dotted(tree, dotted_key, value)

    # 4. Validate into the typed schema.
    try:
        return Config.model_validate(tree)
    except Exception as exc:  # pragma: no cover - re-raised with context
        raise ConfigError(f"configuration failed validation:\n{exc}") from exc


# ---------------------------------------------------------------------------
# Serialisation and hashing
# ---------------------------------------------------------------------------


def to_dict(config: Config) -> dict[str, Any]:
    """Return the configuration as a plain, JSON-serialisable dict."""
    return config.model_dump(mode="json")


def _canonical_json(payload: Any) -> str:
    """Deterministic JSON: sorted keys, no insignificant whitespace."""
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def condition_hash(config: Config, length: int = 12) -> str:
    """Hash the *experimental condition* described by a configuration.

    Blocks that describe execution rather than physics (``run``, ``experiment``)
    are excluded, so that N seeds of the same condition share one hash.  This is
    what makes it possible to group, average and compute confidence intervals
    over seeds without any bookkeeping by hand.
    """
    payload = {k: v for k, v in to_dict(config).items() if k not in _NON_CONDITION_BLOCKS}
    digest = hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()
    return digest[:length]


def save_config(config: Config, path: Path | str) -> Path:
    """Write the resolved configuration to YAML alongside its results."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        yaml.safe_dump(to_dict(config), fh, sort_keys=True, default_flow_style=False)
    return path
