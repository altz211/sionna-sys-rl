"""Typed configuration schema for RAN-LAB experiments.

Every simulation run is fully described by a single immutable :class:`Config`
object.  Nothing in the simulator reads a magic number from source code; all
system parameters enter through this schema, which means an experiment is
reproducible from its serialised configuration alone.

Design rules
------------
1. **Frozen.** Configs are immutable once validated, so a run cannot silently
   mutate its own parameters mid-experiment.
2. **`extra="forbid"`.** A typo in a YAML key raises immediately rather than
   being silently ignored — the classic source of irreproducible results.
3. **Units in field names.** ``isd_m``, ``carrier_frequency_hz``,
   ``tx_power_dbm``.  Unit errors are the most common bug in link budgets.
4. **Standards citations in docstrings.** Every default that comes from a
   specification carries its clause reference, so the model is auditable.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

__all__ = [
    "AgentConfig",
    "ChannelConfig",
    "Config",
    "ExperimentConfig",
    "PhyConfig",
    "PowerConfig",
    "RunConfig",
    "ScenarioConfig",
    "SchedulerConfig",
    "SimConfig",
    "TrafficConfig",
]


class _Base(BaseModel):
    """Common policy for every config block: immutable and strictly validated."""

    model_config = ConfigDict(frozen=True, extra="forbid", validate_default=True)


# ---------------------------------------------------------------------------
# Deployment scenario
# ---------------------------------------------------------------------------


class ScenarioConfig(_Base):
    """Network deployment geometry and user-equipment population.

    Defaults follow the 3GPP TR 38.901 Urban Micro (UMi) Street Canyon
    evaluation assumptions: hexagonal layout, 200 m inter-site distance,
    10 m base-station height, 1.5 m UE height.
    """

    name: str = Field(description="Human-readable scenario label used in reports.")
    layout: Literal["hex_grid", "real_topology"] = Field(
        default="hex_grid",
        description="Synthetic 3GPP hexagonal grid, or real base-station coordinates.",
    )
    n_rings: int = Field(
        default=1,
        ge=0,
        le=3,
        description="Rings of sites around the centre site. 1 ring = 7 sites, 2 = 19.",
    )
    sectors_per_site: int = Field(
        default=3, ge=1, le=3, description="Sectors (cells) per site; 3 is the 3GPP default."
    )
    isd_m: float = Field(
        default=200.0,
        gt=0,
        description="Inter-site distance in metres. TR 38.901: 200 m UMi, 500 m UMa.",
    )
    n_ue_per_cell: int = Field(
        default=10, ge=1, description="Average number of UEs dropped per cell."
    )
    ue_speed_kmph: float = Field(
        default=3.0,
        ge=0,
        description="UE speed in km/h. 3 km/h pedestrian, 30 km/h vehicular (TR 38.901).",
    )
    bs_height_m: float = Field(default=10.0, gt=0, description="Base-station antenna height.")
    ue_height_m: float = Field(default=1.5, gt=0, description="UE antenna height.")
    min_bs_ue_distance_m: float = Field(
        default=10.0, ge=0, description="Minimum 2-D BS-UE separation enforced at drop time."
    )
    topology_file: str | None = Field(
        default=None,
        description="Path to real base-station coordinates (required when layout='real_topology').",
    )
    wrap_around: bool = Field(
        default=True,
        description="Toroidal wrap-around to remove edge effects in interference statistics.",
    )

    @model_validator(mode="after")
    def _check_topology_file(self) -> ScenarioConfig:
        if self.layout == "real_topology" and not self.topology_file:
            raise ValueError("layout='real_topology' requires 'topology_file' to be set")
        return self

    @property
    def n_sites(self) -> int:
        """Number of sites in a hexagonal layout with ``n_rings`` rings."""
        return 1 + 3 * self.n_rings * (self.n_rings + 1)

    @property
    def n_cells(self) -> int:
        """Total number of cells (sectors) in the deployment."""
        return self.n_sites * self.sectors_per_site


# ---------------------------------------------------------------------------
# Propagation channel
# ---------------------------------------------------------------------------


class ChannelConfig(_Base):
    """Radio propagation model and spectrum parameters.

    ``stub`` is a deterministic analytic placeholder used by the Phase-0
    harness and by CI; the real models are 3GPP TR 38.901 UMi / UMa.
    """

    name: str = Field(description="Human-readable channel label used in reports.")
    model: Literal["stub", "tr38901_umi", "tr38901_uma"] = Field(
        default="stub", description="Propagation model backend."
    )
    carrier_frequency_hz: float = Field(
        default=3.5e9, gt=0, description="Carrier frequency. 3.5 GHz is the 5G NR n78 mid-band."
    )
    bandwidth_hz: float = Field(
        default=20e6, gt=0, description="System bandwidth per cell."
    )
    n_prb: int = Field(
        default=51,
        ge=1,
        description="Physical resource blocks. 51 PRB = 20 MHz at 30 kHz SCS (TS 38.104 5.3.2).",
    )
    subcarrier_spacing_hz: float = Field(
        default=30e3, gt=0, description="NR numerology. 30 kHz is SCS configuration mu=1."
    )
    shadowing_std_db: float = Field(
        default=4.0,
        ge=0,
        description="Log-normal shadow-fading std dev. TR 38.901 Table 7.4.1-1: 4 dB UMi LOS.",
    )
    shadowing_correlation_distance_m: float = Field(
        default=10.0, gt=0, description="Spatial de-correlation distance for shadow fading."
    )
    los_model: Literal["tr38901", "always_los", "always_nlos"] = Field(
        default="tr38901", description="Line-of-sight probability model."
    )
    noise_figure_db: float = Field(
        default=9.0, ge=0, description="UE receiver noise figure. TR 38.901 evaluation default."
    )
    thermal_noise_dbm_per_hz: float = Field(
        default=-174.0, description="kTB at 290 K, in dBm/Hz."
    )
    include_interference: bool = Field(
        default=True, description="Model inter-cell interference (False gives a noise-limited bound)."
    )


# ---------------------------------------------------------------------------
# Traffic
# ---------------------------------------------------------------------------


class TrafficConfig(_Base):
    """Downlink traffic demand model.

    ``full_buffer`` is the classical upper-bound assumption (every UE always
    has data).  ``ftp3`` is the 3GPP FTP Model 3 bursty model, in which
    fixed-size payloads arrive as a Poisson process per UE.
    """

    name: str = Field(description="Human-readable traffic label used in reports.")
    model: Literal["full_buffer", "ftp3"] = Field(
        default="full_buffer", description="Traffic arrival model."
    )
    packet_size_bits: int = Field(
        default=4_194_304,
        gt=0,
        description="FTP Model 3 payload size. 0.5 MByte is the 3GPP default.",
    )
    arrival_rate_per_ue_per_s: float = Field(
        default=1.0, gt=0, description="Poisson arrival rate per UE (FTP Model 3 only)."
    )
    offered_load_scale: float = Field(
        default=1.0,
        gt=0,
        description="Multiplier on offered load; the primary axis for load sweeps.",
    )


# ---------------------------------------------------------------------------
# Physical-layer abstraction
# ---------------------------------------------------------------------------


class PhyConfig(_Base):
    """Link-to-system mapping: how SINR becomes a decoded transport block.

    System-level simulators do not simulate the waveform.  They map the
    post-equaliser SINR onto a block-error probability through a link-level
    abstraction (here EESM, Exponential Effective SINR Mapping), then apply
    link adaptation and HARQ.
    """

    abstraction: Literal["stub", "eesm", "shannon"] = Field(
        default="stub", description="Link-to-system mapping method."
    )
    target_bler: float = Field(
        default=0.1,
        gt=0,
        lt=1,
        description="Link-adaptation BLER operating point. 10% is the NR first-transmission target.",
    )
    mcs_table: Literal["qam64", "qam256"] = Field(
        default="qam64", description="NR MCS table (TS 38.214 Tables 5.1.3.1-1 / 5.1.3.1-2)."
    )
    max_harq_retx: int = Field(
        default=3, ge=0, description="Maximum HARQ retransmissions per transport block."
    )
    cqi_report_period_slots: int = Field(
        default=5, ge=1, description="CQI reporting periodicity."
    )
    cqi_delay_slots: int = Field(
        default=2, ge=0, description="CSI ageing: delay between measurement and use."
    )
    spectral_efficiency_cap_bps_hz: float = Field(
        default=7.4063,
        gt=0,
        description="Peak SE ceiling. 7.4063 bps/Hz is NR MCS table 2 index 27.",
    )


# ---------------------------------------------------------------------------
# Transmit power
# ---------------------------------------------------------------------------


class PowerConfig(_Base):
    """Downlink transmit-power configuration and control policy."""

    tx_power_dbm: float = Field(
        default=44.0, description="Per-cell total downlink transmit power. 44 dBm typical for UMi."
    )
    control: Literal["fixed", "learned"] = Field(
        default="fixed", description="Power-allocation policy family."
    )
    min_tx_power_dbm: float = Field(default=20.0, description="Lower bound for power control.")
    max_tx_power_dbm: float = Field(default=46.0, description="Upper bound for power control.")
    circuit_power_w: float = Field(
        default=130.0,
        ge=0,
        description="Static per-cell power draw, used for energy-per-bit accounting.",
    )
    pa_efficiency: float = Field(
        default=0.35, gt=0, le=1, description="Power-amplifier efficiency."
    )

    @model_validator(mode="after")
    def _check_power_bounds(self) -> PowerConfig:
        if self.min_tx_power_dbm > self.max_tx_power_dbm:
            raise ValueError("min_tx_power_dbm must not exceed max_tx_power_dbm")
        return self


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------


class SchedulerConfig(_Base):
    """Radio resource management policy under test.

    All policies implement the same interface and observe the same state, so
    the learned policy receives no privileged information relative to the
    classical baselines.
    """

    name: str = Field(description="Human-readable policy label used in reports and plots.")
    algorithm: Literal["round_robin", "proportional_fair", "max_ci", "learned"] = Field(
        description="Scheduling policy family."
    )
    pf_alpha: float = Field(
        default=1.0,
        ge=0,
        description="Proportional-fair throughput exponent (alpha=1 is classical PF).",
    )
    pf_beta: float = Field(
        default=1.0, ge=0, description="Proportional-fair rate exponent."
    )
    pf_ewma_window_slots: int = Field(
        default=100, ge=1, description="Averaging window for the PF throughput estimate."
    )
    policy_checkpoint: str | None = Field(
        default=None, description="Path to trained weights (required when algorithm='learned')."
    )

    @model_validator(mode="after")
    def _check_checkpoint(self) -> SchedulerConfig:
        if self.algorithm == "learned" and not self.policy_checkpoint:
            raise ValueError("algorithm='learned' requires 'policy_checkpoint' to be set")
        return self


# ---------------------------------------------------------------------------
# Learned-policy training
# ---------------------------------------------------------------------------


class AgentConfig(_Base):
    """Reinforcement-learning agent hyperparameters (Phase 4)."""

    name: str = Field(default="none", description="Agent label; 'none' disables training.")
    algorithm: Literal["none", "ppo", "dqn", "sac"] = Field(
        default="none", description="RL algorithm."
    )
    total_timesteps: int = Field(default=100_000, ge=0, description="Training budget.")
    learning_rate: float = Field(default=3e-4, gt=0, description="Optimiser learning rate.")
    gamma: float = Field(default=0.99, ge=0, le=1, description="Discount factor.")
    batch_size: int = Field(default=64, ge=1, description="Mini-batch size.")
    hidden_sizes: tuple[int, ...] = Field(
        default=(128, 128), description="Policy-network hidden layer widths."
    )
    reward: Literal["sum_log_rate", "sum_rate", "edge_rate", "energy_aware"] = Field(
        default="sum_log_rate",
        description="Reward function. sum_log_rate is the proportional-fair objective.",
    )


# ---------------------------------------------------------------------------
# Simulation control
# ---------------------------------------------------------------------------


class SimConfig(_Base):
    """Temporal extent and resolution of a single simulation run."""

    n_slots: int = Field(default=1000, ge=1, description="Simulated slots after warm-up.")
    warmup_slots: int = Field(
        default=100,
        ge=0,
        description="Discarded leading slots, so KPIs exclude transient behaviour.",
    )
    slot_duration_s: float = Field(
        default=0.5e-3, gt=0, description="NR slot duration. 0.5 ms at 30 kHz SCS."
    )
    collect_per_slot_traces: bool = Field(
        default=False, description="Persist per-slot traces (large; off by default)."
    )


# ---------------------------------------------------------------------------
# Run bookkeeping
# ---------------------------------------------------------------------------


class RunConfig(_Base):
    """Bookkeeping for a single execution.

    ``seed``, ``output_dir`` and ``tag`` are excluded from the configuration
    hash: the hash identifies the *experimental condition*, so that repeated
    seeds of the same condition group together during analysis.
    """

    seed: int = Field(default=0, ge=0, description="Master PRNG seed for this run.")
    n_seeds: int = Field(
        default=1, ge=1, description="Independent seeds to execute for this condition."
    )
    output_dir: str = Field(default="results/raw", description="Destination for result artefacts.")
    tag: str | None = Field(default=None, description="Optional free-text label for this run.")


# ---------------------------------------------------------------------------
# Sweeps
# ---------------------------------------------------------------------------


class ExperimentConfig(_Base):
    """A parameter sweep: the Cartesian product of the listed axes.

    Example
    -------
    ``sweep = {"scenario.n_ue_per_cell": [5, 10, 20],
    "scheduler": ["round_robin", "proportional_fair"]}``
    expands to six conditions, each executed for ``run.n_seeds`` seeds.
    """

    name: str = Field(default="single", description="Experiment label used in report titles.")
    description: str = Field(default="", description="One-line statement of the question asked.")
    sweep: dict[str, list] = Field(
        default_factory=dict,
        description="Map of dotted config key (or config-group name) to the values to sweep.",
    )
    n_workers: int = Field(
        default=1, ge=1, description="Parallel worker processes for sweep execution."
    )


# ---------------------------------------------------------------------------
# Root
# ---------------------------------------------------------------------------


class Config(_Base):
    """The complete, validated description of a RAN-LAB experiment."""

    scenario: ScenarioConfig
    channel: ChannelConfig
    traffic: TrafficConfig
    phy: PhyConfig = Field(default_factory=PhyConfig)
    power: PowerConfig = Field(default_factory=PowerConfig)
    scheduler: SchedulerConfig
    agent: AgentConfig = Field(default_factory=AgentConfig)
    sim: SimConfig = Field(default_factory=SimConfig)
    run: RunConfig = Field(default_factory=RunConfig)
    experiment: ExperimentConfig = Field(default_factory=ExperimentConfig)

    @model_validator(mode="after")
    def _check_consistency(self) -> Config:
        if self.channel.include_interference and self.scenario.n_cells == 1:
            raise ValueError(
                "include_interference=True is meaningless with a single cell; "
                "increase scenario.n_rings or set channel.include_interference=False"
            )
        return self
