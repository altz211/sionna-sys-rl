"""Result schema and Parquet I/O.

Two tables are written per simulation run:

``<run_id>.ue.parquet``
    One row per UE.  This is the primary analysis unit — throughput CDFs and
    the 5th-percentile cell-edge KPI are computed from the UE distribution,
    not from cell averages, because averaging away the tail is precisely what
    hides a scheduler's effect on cell-edge users.

``<run_id>.run.parquet``
    One row per run, holding aggregate KPIs that have no per-UE meaning
    (fairness index, per-cell energy, wall-clock runtime).

``<run_id>.meta.json``
    Full provenance record and the complete resolved configuration.

Every row in both tables carries its provenance columns and the condition
descriptors, so a results table is self-describing and can be grouped,
filtered and plotted without joining back to the configuration files.

The schemas are declared explicitly in Arrow rather than inferred from a
DataFrame.  Inferred schemas drift silently — a column that is all-null in
one run becomes ``null`` dtype and refuses to concatenate with a later run.
Pinning the schema turns that class of bug into an immediate, loud failure.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from ranlab.config import Config, to_dict
from ranlab.io.provenance import Provenance

__all__ = [
    "RUN_SCHEMA",
    "UE_SCHEMA",
    "ResultSchemaError",
    "condition_columns",
    "load_results",
    "read_meta",
    "write_run_results",
]


class ResultSchemaError(ValueError):
    """Raised when a results table does not match the declared schema."""


# ---------------------------------------------------------------------------
# Schema fragments
# ---------------------------------------------------------------------------

_PROVENANCE_FIELDS = [
    pa.field("run_id", pa.string(), nullable=False),
    pa.field("condition_hash", pa.string(), nullable=False),
    pa.field("seed", pa.int32(), nullable=False),
    pa.field("experiment", pa.string(), nullable=False),
    pa.field("timestamp_utc", pa.string(), nullable=False),
    pa.field("git_commit", pa.string()),
    pa.field("git_dirty", pa.bool_()),
    pa.field("ranlab_version", pa.string()),
]

# Condition descriptors: the sweep axes, denormalised onto every row so that
# plotting code can group by them directly.
_CONDITION_FIELDS = [
    pa.field("scenario", pa.string(), nullable=False),
    pa.field("channel_model", pa.string(), nullable=False),
    pa.field("traffic_model", pa.string(), nullable=False),
    pa.field("scheduler", pa.string(), nullable=False),
    pa.field("phy_abstraction", pa.string(), nullable=False),
    pa.field("power_control", pa.string(), nullable=False),
    pa.field("n_cells", pa.int32(), nullable=False),
    pa.field("n_ue_per_cell", pa.int32(), nullable=False),
    pa.field("ue_speed_kmph", pa.float32(), nullable=False),
    pa.field("offered_load_scale", pa.float32(), nullable=False),
    pa.field("tx_power_dbm", pa.float32(), nullable=False),
    pa.field("bandwidth_hz", pa.float64(), nullable=False),
    pa.field("isd_m", pa.float32(), nullable=False),
]

# Per-UE measurements.
_UE_FIELDS = [
    pa.field("ue_id", pa.int32(), nullable=False),
    pa.field("serving_cell_id", pa.int32(), nullable=False),
    pa.field("x_m", pa.float32()),
    pa.field("y_m", pa.float32()),
    pa.field("distance_to_serving_m", pa.float32()),
    pa.field("is_los", pa.bool_()),
    pa.field("mean_sinr_db", pa.float32()),
    pa.field("p10_sinr_db", pa.float32()),
    pa.field("mean_wideband_sinr_db", pa.float32()),
    pa.field("throughput_bps", pa.float64(), nullable=False),
    pa.field("spectral_efficiency_bps_hz", pa.float32()),
    pa.field("bler", pa.float32()),
    pa.field("mean_latency_ms", pa.float32()),
    pa.field("p95_latency_ms", pa.float32()),
    pa.field("served_bits", pa.float64()),
    pa.field("n_scheduled_slots", pa.int32()),
    pa.field("prb_share", pa.float32()),
]

# Run-level aggregates.
_RUN_FIELDS = [
    pa.field("n_ue", pa.int32(), nullable=False),
    pa.field("n_slots", pa.int32(), nullable=False),
    pa.field("warmup_slots", pa.int32(), nullable=False),
    pa.field("mean_ue_throughput_bps", pa.float64(), nullable=False),
    pa.field("p5_ue_throughput_bps", pa.float64(), nullable=False),
    pa.field("p50_ue_throughput_bps", pa.float64()),
    pa.field("p95_ue_throughput_bps", pa.float64()),
    pa.field("cell_throughput_bps", pa.float64()),
    pa.field("spectral_efficiency_bps_hz", pa.float32()),
    pa.field("jain_fairness", pa.float32()),
    pa.field("mean_bler", pa.float32()),
    pa.field("mean_latency_ms", pa.float32()),
    pa.field("p95_latency_ms", pa.float32()),
    pa.field("energy_per_bit_nj", pa.float64()),
    pa.field("total_energy_j", pa.float64()),
    pa.field("sim_runtime_s", pa.float32()),
]

UE_SCHEMA = pa.schema(_PROVENANCE_FIELDS + _CONDITION_FIELDS + _UE_FIELDS)
"""Arrow schema for the per-UE results table."""

RUN_SCHEMA = pa.schema(_PROVENANCE_FIELDS + _CONDITION_FIELDS + _RUN_FIELDS)
"""Arrow schema for the per-run aggregate results table."""


# ---------------------------------------------------------------------------
# Condition descriptors
# ---------------------------------------------------------------------------


def condition_columns(config: Config) -> dict[str, Any]:
    """Extract the denormalised condition descriptors from a configuration.

    These are the columns analysis code groups by.  They intentionally mirror
    the sweep axes declared in ``configs/experiment/*.yaml``.
    """
    return {
        "scenario": config.scenario.name,
        "channel_model": config.channel.model,
        "traffic_model": config.traffic.model,
        "scheduler": config.scheduler.name,
        "phy_abstraction": config.phy.abstraction,
        "power_control": config.power.control,
        "n_cells": int(config.scenario.n_cells),
        "n_ue_per_cell": int(config.scenario.n_ue_per_cell),
        "ue_speed_kmph": float(config.scenario.ue_speed_kmph),
        "offered_load_scale": float(config.traffic.offered_load_scale),
        "tx_power_dbm": float(config.power.tx_power_dbm),
        "bandwidth_hz": float(config.channel.bandwidth_hz),
        "isd_m": float(config.scenario.isd_m),
    }


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------


def _to_table(rows: pd.DataFrame, schema: pa.Schema, label: str) -> pa.Table:
    """Cast a DataFrame to the declared schema, failing loudly on mismatch."""
    missing = [f.name for f in schema if f.name not in rows.columns]
    if missing:
        raise ResultSchemaError(f"{label} table is missing required columns: {missing}")
    extra = [c for c in rows.columns if c not in schema.names]
    if extra:
        raise ResultSchemaError(
            f"{label} table has undeclared columns: {extra}. "
            "Add them to the schema in ranlab/io/results.py rather than writing them ad hoc."
        )
    ordered = rows[[f.name for f in schema]]
    try:
        return pa.Table.from_pandas(ordered, schema=schema, preserve_index=False)
    except (pa.ArrowInvalid, pa.ArrowTypeError) as exc:
        raise ResultSchemaError(f"{label} table failed schema validation: {exc}") from exc


def write_run_results(
    output_dir: Path | str,
    config: Config,
    provenance: Provenance,
    ue_rows: Iterable[Mapping[str, Any]] | pd.DataFrame,
    run_row: Mapping[str, Any],
) -> dict[str, Path]:
    """Write the UE table, run table and metadata sidecar for one run.

    Parameters
    ----------
    output_dir
        Destination directory; created if absent.
    config
        The resolved configuration that produced this run.
    provenance
        Provenance captured at run start.
    ue_rows
        Per-UE measurements; the provenance and condition columns are added here.
    run_row
        Run-level aggregate KPIs.

    Returns
    -------
    dict
        Paths of the three artefacts written, keyed ``ue``, ``run`` and ``meta``.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    stamp = {**provenance.to_columns(), **condition_columns(config)}

    ue_df = pd.DataFrame(ue_rows) if not isinstance(ue_rows, pd.DataFrame) else ue_rows.copy()
    if ue_df.empty:
        raise ResultSchemaError("refusing to write an empty UE results table")
    for key, value in stamp.items():
        ue_df[key] = value

    run_df = pd.DataFrame([{**dict(run_row), **stamp}])

    ue_path = output_dir / f"{provenance.run_id}.ue.parquet"
    run_path = output_dir / f"{provenance.run_id}.run.parquet"
    meta_path = output_dir / f"{provenance.run_id}.meta.json"

    pq.write_table(_to_table(ue_df, UE_SCHEMA, "UE"), ue_path, compression="zstd")
    pq.write_table(_to_table(run_df, RUN_SCHEMA, "run"), run_path, compression="zstd")

    meta = {
        "provenance": provenance.to_dict(),
        "config": to_dict(config),
        "artefacts": {"ue": ue_path.name, "run": run_path.name},
    }
    meta_path.write_text(json.dumps(meta, indent=2, sort_keys=True, default=str), encoding="utf-8")

    return {"ue": ue_path, "run": run_path, "meta": meta_path}


# ---------------------------------------------------------------------------
# Reading
# ---------------------------------------------------------------------------


def load_results(
    results_dir: Path | str = "results/raw",
    level: str = "run",
) -> pd.DataFrame:
    """Load and concatenate every result table of one level in a directory.

    Parameters
    ----------
    results_dir
        Directory of ``*.ue.parquet`` / ``*.run.parquet`` files.
    level
        ``"run"`` for aggregate KPIs, ``"ue"`` for the per-UE distribution.
    """
    if level not in {"run", "ue"}:
        raise ValueError("level must be 'run' or 'ue'")
    results_dir = Path(results_dir)
    paths = sorted(results_dir.glob(f"*.{level}.parquet"))
    if not paths:
        raise FileNotFoundError(
            f"no *.{level}.parquet files found in {results_dir}. Run `make sim` or `make sweep` first."
        )
    schema = RUN_SCHEMA if level == "run" else UE_SCHEMA
    table = pa.concat_tables([pq.read_table(p, schema=schema) for p in paths])
    return table.to_pandas()


def read_meta(results_dir: Path | str, run_id: str) -> dict[str, Any]:
    """Read the metadata sidecar for a single run."""
    path = Path(results_dir) / f"{run_id}.meta.json"
    if not path.is_file():
        raise FileNotFoundError(f"no metadata sidecar for run {run_id} in {results_dir}")
    return json.loads(path.read_text(encoding="utf-8"))
