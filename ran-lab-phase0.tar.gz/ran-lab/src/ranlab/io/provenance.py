"""Provenance stamping: the record of exactly how a result was produced.

Every result file carries a :class:`Provenance` record.  The purpose is
falsifiability: given any figure in this repository, the reader can recover
the exact code revision, configuration, seed and software environment that
produced it, and re-run it.

The fields are chosen so that the three usual causes of an irreproducible
result are all detectable:

* **Code drift** — ``git_commit`` plus ``git_dirty``.  A result produced from
  an uncommitted working tree is flagged, not silently trusted.
* **Configuration drift** — ``condition_hash`` over the resolved config.
* **Environment drift** — interpreter version, platform and the versions of
  the numerical libraries whose behaviour can change results.
"""

from __future__ import annotations

import getpass
import platform
import socket
import subprocess
import sys
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any

__all__ = ["Provenance", "capture_provenance", "git_info", "environment_info"]

# Libraries whose version can change numerical results and must be recorded.
_TRACKED_PACKAGES = (
    "ranlab",
    "numpy",
    "scipy",
    "pandas",
    "pyarrow",
    "pydantic",
    "PyYAML",
    "sionna",
    "torch",
    "gymnasium",
    "stable-baselines3",
)


def _run_git(args: list[str], repo_root: Path) -> str | None:
    """Run a git command, returning stripped stdout or None if unavailable."""
    try:
        result = subprocess.run(  # noqa: S603
            ["git", *args],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    return result.stdout.strip() or None


def git_info(repo_root: Path | str | None = None) -> dict[str, Any]:
    """Collect the code revision, branch and working-tree cleanliness.

    Returns ``git_commit=None`` when the code is not running from a git
    checkout (for example inside a built container image), which is itself
    recorded rather than hidden.
    """
    root = Path(repo_root) if repo_root is not None else Path.cwd()
    commit = _run_git(["rev-parse", "HEAD"], root)
    if commit is None:
        return {"git_commit": None, "git_branch": None, "git_dirty": None}
    status = _run_git(["status", "--porcelain"], root)
    return {
        "git_commit": commit,
        "git_branch": _run_git(["rev-parse", "--abbrev-ref", "HEAD"], root),
        "git_dirty": bool(status),
    }


def environment_info() -> dict[str, Any]:
    """Capture interpreter, platform and tracked package versions."""
    packages: dict[str, str] = {}
    for name in _TRACKED_PACKAGES:
        try:
            packages[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            continue
    return {
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or None,
        "packages": packages,
    }


def _safe_user() -> str | None:
    try:
        return getpass.getuser()
    except Exception:  # pragma: no cover - depends on the host
        return None


def _safe_host() -> str | None:
    try:
        return socket.gethostname()
    except Exception:  # pragma: no cover - depends on the host
        return None


@dataclass(frozen=True)
class Provenance:
    """Immutable record of how one simulation run was produced."""

    run_id: str
    condition_hash: str
    seed: int
    experiment: str
    timestamp_utc: str
    ranlab_version: str
    git_commit: str | None = None
    git_branch: str | None = None
    git_dirty: bool | None = None
    python_version: str = ""
    platform: str = ""
    machine: str = ""
    processor: str | None = None
    hostname: str | None = None
    username: str | None = None
    packages: dict[str, str] = field(default_factory=dict)
    duration_s: float | None = None
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable dict of the full record."""
        return asdict(self)

    def to_columns(self) -> dict[str, Any]:
        """Return the flat subset embedded as columns in every result row.

        Keeping these in the Parquet file itself — rather than only in a
        sidecar — means a result table is self-describing even if it is copied
        away from its metadata, and lets analysis filter by commit or seed
        without a join.
        """
        return {
            "run_id": self.run_id,
            "condition_hash": self.condition_hash,
            "seed": self.seed,
            "experiment": self.experiment,
            "timestamp_utc": self.timestamp_utc,
            "git_commit": self.git_commit,
            "git_dirty": self.git_dirty,
            "ranlab_version": self.ranlab_version,
        }

    @property
    def is_reproducible(self) -> bool:
        """True when the run came from a clean, identifiable git checkout."""
        return self.git_commit is not None and self.git_dirty is False

    def warnings(self) -> list[str]:
        """Human-readable caveats to surface in reports."""
        issues: list[str] = []
        if self.git_commit is None:
            issues.append("No git revision recorded: this result cannot be tied to a code version.")
        elif self.git_dirty:
            issues.append(
                "Working tree was dirty: uncommitted changes may not be recoverable."
            )
        return issues


def capture_provenance(
    condition_hash: str,
    seed: int,
    experiment: str = "single",
    repo_root: Path | str | None = None,
    notes: str | None = None,
) -> Provenance:
    """Capture a complete provenance record for a run about to start."""
    try:
        version = metadata.version("ranlab")
    except metadata.PackageNotFoundError:
        version = "0.0.0+unpackaged"

    env = environment_info()
    return Provenance(
        run_id=uuid.uuid4().hex[:16],
        condition_hash=condition_hash,
        seed=seed,
        experiment=experiment,
        timestamp_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        ranlab_version=version,
        **git_info(repo_root),
        python_version=env["python_version"],
        platform=env["platform"],
        machine=env["machine"],
        processor=env["processor"],
        hostname=_safe_host(),
        username=_safe_user(),
        packages=env["packages"],
        notes=notes,
    )
