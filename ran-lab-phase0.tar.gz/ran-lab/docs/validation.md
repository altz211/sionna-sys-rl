# Validation

A simulator that runs is not a simulator that is correct. This document
records the gates that must pass before results from a given phase may be
quoted, and the status of each.

Tests live in `tests/validation/` and are marked `@pytest.mark.validation`.
They are written **before** the code they validate, so the acceptance criteria
are in the repository rather than in somebody's memory. They currently skip
with a reason naming the phase that will implement them.

---

## Gate status

| # | Gate | Phase | Status |
|---|---|---|---|
| V1 | UMi wideband SINR CDF matches the 3GPP calibration reference | 1 | ⬜ pending |
| V2 | Coupling-loss CDF matches the same reference | 1 | ⬜ pending |
| V3 | EESM reproduces tabulated NR link-level BLER curves | 1 | ⬜ pending |
| V4 | Noise-limited single cell approaches the Shannon bound | 1 | ⬜ pending |
| V5 | Little's law holds under FTP Model 3 | 2 | ⬜ pending |
| V6 | Classical scheduler throughput ordering | 2 | ✅ holds on placeholder physics |
| V7 | Max C/I is least fair on both fairness measures | 2 | ✅ holds on placeholder physics |
| V8 | Channel-aware gain erodes with CSI ageing at high mobility | 2 | ⬜ pending |
| V9 | Learned policy receives no privileged information | 4 | ⬜ pending |
| R1 | Identical results under serial and parallel execution | 0 | ✅ passing |
| R2 | Identical results from the same seed | 0 | ✅ passing |
| R3 | Every result carries a recoverable code revision | 0 | ✅ passing |

---

## Why these gates

### V1, V2 — the channel
The SINR distribution is upstream of every other KPI. If it is wrong,
nothing downstream is worth measuring, however careful the scheduler code is.

The two gates separate two failure modes. **Coupling loss** depends only on
the link budget — path loss, shadowing, antenna gain — so a mismatch localises
the bug to propagation. **SINR** additionally involves interference and
serving-cell assignment, so a gate that passes V2 and fails V1 localises the
bug to interference modelling.

*Reference*: 3GPP TR 38.901 / TR 36.873 calibration results, UMi Street
Canyon, 200 m ISD, 3.5 GHz, 3-sector.
*Criterion*: 5th, 50th and 95th percentiles each within 1.5 dB.

### V3 — the PHY abstraction
EESM exists to reproduce link-level BLER without simulating the waveform. If
the abstraction does not match the curves it abstracts, it is not an
abstraction, it is an invention.
*Criterion*: SINR at 10% BLER within 0.5 dB, per MCS.

### V4 — the link budget
An analytic sanity check requiring no external data. With interference off and
ideal link adaptation, spectral efficiency must track `log₂(1 + SINR)` to
within the modelled implementation margin. This catches unit errors — dB vs
linear, dBm vs dBW, MHz vs Hz — which otherwise hide as a plausible-looking
constant offset that no KPI inspection would reveal.

### V5 — traffic and latency accounting
Little's law (`L = λW`) is an identity, not an approximation. Any violation is
an accounting bug in the buffer or latency instrumentation, not a modelling
choice.

### V6, V7 — scheduler correctness
Policy orderings are properties of the *policies*, not of the channel, so they
must hold even on placeholder physics — and they do
(`tests/integration/test_pipeline.py::TestSchedulerOrdering`).

Note the asymmetry in V7. Round Robin is fairest in **airtime** by
construction. It is *not* necessarily fairest in **throughput**: equal airtime
converts into unequal bits, because a cell-edge UE turns its slots into far
fewer of them. Proportional Fair frequently attains both higher throughput and
a higher Jain index than Round Robin. The definition-independent claim, and
the one asserted, is that **Max C/I is least fair on both measures**.

### V8 — CSI ageing
A falsifiable prediction, and the sharpest test of whether the CSI-reporting
model is real. As UE speed rises, the reported rate becomes a worse predictor
of the delivered rate, so channel-aware policies must lose their advantage
over Round Robin. If they do not, CSI ageing is not actually being modelled
and every mobility result is meaningless.

### V9 — the integrity of the learned-policy comparison
The most important gate in the repository. If the RL observation exposes
anything the classical baselines cannot see, any reported gain is an artefact
of the experimental setup, not a property of the policy.

*Method*: freeze the learned policy's weights to imitate PF exactly; its KPIs
must then match the PF baseline to within seed noise. A discrepancy proves an
asymmetry in the observation space.

### R1–R3 — reproducibility
Already enforced. R1 in particular is easy to lose: a shared RNG or
completion-order-dependent aggregation silently makes results depend on the
worker count, and the failure is invisible without a test that looks for it.

---

## Running the gates

```bash
pytest -m validation -v          # validation gates only
pytest -m "not slow" -q          # fast lane, as used in CI
pytest --cov=ranlab              # everything, with coverage
```

## Promotion rule

A phase's results may be quoted only when every gate for that phase and all
earlier phases passes. Until then the generated report carries a caveat
banner naming the placeholder components, and the README states the phase.

This rule is the reason the repository can be read as evidence of method
rather than as a collection of plots.
