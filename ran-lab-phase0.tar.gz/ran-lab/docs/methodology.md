# System model

This document states the model RAN-LAB simulates, its assumptions, and the
standards clauses each parameter comes from. It is the document to read before
trusting any number the simulator produces.

> **Phase 0 status.** The channel and physical-layer abstraction are currently
> placeholders. Sections marked **[PLACEHOLDER]** describe what is implemented
> today; sections marked **[PHASE 1]** describe what replaces it. No result
> produced before the Phase-1 validation gates pass should be quoted.

---

## 1. Scope

RAN-LAB is a **system-level** simulator. It does not generate or process a
waveform. It models a multi-cell downlink at the granularity of a scheduling
slot, and answers questions of the form: *given this deployment, this traffic
and this resource-management policy, what throughput, fairness, latency and
energy does the network deliver?*

Questions it cannot answer: anything about waveform design, receiver
algorithms, channel estimation or coding. Those require a link-level
simulator; the interface between the two is the physical-layer abstraction
described in §5.

## 2. Deployment

Sites are placed on a triangular lattice at inter-site distance `isd_m`.
`n_rings` rings around a centre site give `1 + 3n(n+1)` sites: 7 at one ring,
19 at two. Each site carries `sectors_per_site` cells; with three sectors the
boresights are at 30°, 150° and 270°.

| Parameter | UMi default | UMa default | Source |
|---|---|---|---|
| Inter-site distance | 200 m | 500 m | TR 38.901 Table 7.2-1 |
| BS height | 10 m | 25 m | TR 38.901 Table 7.2-1 |
| UE height | 1.5 m | 1.5 m | TR 38.901 Table 7.2-1 |
| Min. BS–UE 2-D distance | 10 m | 35 m | TR 38.901 Table 7.2-1 |
| Carrier frequency | 3.5 GHz | 3.5 GHz | NR band n78 |
| Bandwidth / PRBs | 20 MHz / 51 | 20 MHz / 51 | TS 38.104 Table 5.3.2-1 |
| Subcarrier spacing | 30 kHz (μ=1) | 30 kHz | TS 38.211 |

UEs are dropped uniformly over the layout's bounding square, **not** per cell.
Per-cell dropping forces every cell to hold the same number of UEs, which
removes the load imbalance that schedulers exist to handle. Under uniform
dropping the UE count per cell is a random variable, as in reality.

### 2.1 Wrap-around

The simulated region is toroidal: distance uses the nearest periodic image of
each cell. Without this, cells at the edge of a finite grid have fewer
interfering neighbours than interior cells, so their SINR is optimistically
biased — and because edge cells are a large fraction of a 7-site layout, that
bias contaminates the whole SINR distribution.

### 2.2 Antenna pattern

Horizontal sector pattern from TR 38.901 Table 7.3-1:

```
A(φ) = −min[ 12 (φ / φ_3dB)² , A_max ],   φ_3dB = 65°,  A_max = 30 dB
```

Vertical pattern and mechanical downtilt are **not** modelled. This is a known
optimism: real downtilt suppresses inter-cell interference, so the simulated
SINR distribution is pessimistic relative to a tilted deployment.

## 3. Serving-cell assignment

Each UE attaches to the cell maximising received power, approximated by
sector antenna gain minus 20·log₁₀(distance). Assignment is fixed for the run:
**no handover is modelled**, so mobility results are valid only over intervals
short relative to cell-crossing time.

## 4. Propagation

### 4.1 [PLACEHOLDER] Current model

Free-space loss at 1 m plus a fixed exponent:

```
PL(d) = 20·log₁₀(4πd₀/λ) + 10·n·log₁₀(d₃D/d₀),   n = 3.5
```

with i.i.d. log-normal shadowing (σ = 4 dB, no spatial correlation), the
TR 38.901 antenna pattern, and i.i.d. Rayleigh fast fading per slot and link.

Known departures from reality, all of which inflate channel-aware scheduling
gains:

- A single path-loss exponent, independent of LOS state, frequency and height.
- Shadowing uncorrelated in space, so nearby UEs see independent shadowing.
- Fading fully de-correlated between slots, giving maximal and unrealistic
  multi-user diversity.
- Frequency-flat: no selectivity, so no frequency-domain scheduling gain.

### 4.2 [PHASE 1] TR 38.901

Replaced by UMi Street Canyon and UMa: LOS/NLOS probability (Table 7.4.2-1),
per-state path loss (Table 7.4.1-1), per-state shadowing with exponential
spatial correlation, and a correlated fading process with the configured
Doppler. Validated against the published SINR and coupling-loss CDFs
(`docs/validation.md`).

### 4.3 SINR

```
SINR_u = P_serving·g_serving·h_serving / ( Σ_{c≠serving} P_c·g_c·h_c + N )
N = −174 dBm/Hz + 10·log₁₀(B) + NF,   NF = 9 dB
```

All cells transmit at full power in every slot (full-buffer interference).
This is the standard pessimistic assumption; with bursty traffic real
interference is lower and intermittent.

## 5. Physical-layer abstraction

The link-to-system interface. A system-level simulator maps SINR onto a
delivered rate using curves measured by a link-level simulator.

### 5.1 [PLACEHOLDER] Current model

```
SE = min[ log₂(1 + SINR/Δ) , SE_max ],     Δ = 3 dB implementation margin
SE = 0                                      for SINR < −6 dB (outage)
rate = SE · B · (1 − BLER_target)
```

`SE_max = 7.4063 bps/Hz` is the peak of NR MCS table 2 (TS 38.214
Table 5.1.3.1-2).

### 5.2 [PHASE 1] EESM

Exponential Effective SINR Mapping compresses the per-subcarrier SINR vector
to one effective value, from which BLER is looked up per MCS. Link adaptation
selects the highest MCS meeting `target_bler`; HARQ retransmits up to
`max_harq_retx` times with Chase combining.

### 5.3 CSI reporting and ageing

**This is the most consequential modelling choice in the simulator.** Policies
observe a rate estimate refreshed every `cqi_report_period_slots` and held
between refreshes; the delivered rate uses the true instantaneous channel.

The gap between the two is CSI ageing, and it is why channel-aware policies
must lose their advantage as UE speed rises. Handing a scheduler the true
instantaneous channel is the single most common way a simulation study reports
an unachievable gain. The learned policy is held to the same restriction
(`tests/validation`, Phase 4).

## 6. Traffic

**Full buffer** — every UE always backlogged. Isolates scheduler behaviour
from arrival-process effects; the standard throughput upper bound. Latency is
undefined under this model and is reported as NaN.

**[PHASE 2] FTP Model 3** — fixed payloads arriving as a per-UE Poisson
process (TR 36.814 Annex A.2.1.3.1). Finite buffers make latency, buffer
dynamics and offered-load sweeps meaningful.

## 7. Scheduling

One UE is served per cell per slot, receiving all PRBs. The interface
(`ranlab.mac.base`) expresses allocation as a vector of PRB shares, so
multi-user and fractional allocation need no interface change later.

| Policy | Rule |
|---|---|
| Round Robin | next backlogged UE in a fixed rotation |
| Max C/I | `argmax R_i` |
| Proportional Fair | `argmax R_i^β / T̄_i^α`, α=β=1 |

`T̄_i` is an EWMA over `pf_ewma_window_slots`, maintained by the engine so that
every policy observes an identically-defined state. Ties are broken uniformly
at random: deterministic `argmax` favours low-indexed UEs and biases exactly
the fairness statistics being measured.

## 8. Energy

Affine base-station power model:

```
P_cell = P_circuit + P_tx / η,     P_circuit = 130 W, η = 0.35
E = N_cells · P_cell · T
energy per bit = E / Σ delivered bits
```

Energy per bit is the headline efficiency KPI because it rewards delivering
the same traffic with less power, and penalises "saving" power by delivering
less.

## 9. KPIs

The per-UE throughput **distribution** is the primary object; summary
statistics are drawn from it.

| KPI | Definition |
|---|---|
| Mean UE throughput | mean of the per-UE distribution |
| **5th-percentile throughput** | cell-edge indicator, 3GPP convention |
| Cell throughput | total delivered bits / (duration × cells) |
| Spectral efficiency | cell throughput / bandwidth |
| Jain fairness | `(Σx)² / (n·Σx²)`, on throughput |
| BLER | mean residual block-error rate over served slots |
| Energy per bit | §8 |

The 5th percentile is reported alongside the mean throughout, because a mean
alone cannot distinguish "everyone improved" from "the median improved while
the tail collapsed" — and the second is what an aggressive scheduler actually
does.

## 10. Warm-up

The first `warmup_slots` slots advance state but contribute nothing to
reported KPIs. The PF throughput average needs `~pf_ewma_window_slots` to
converge; statistics collected during that transient are not steady-state.

## 11. Randomness and reproducibility

One master seed per run derives every stream: UE drop, shadowing, fading, and
each cell's scheduler tie-breaking. Sweep points derive their seed from
position in the expansion, not from a shared generator, so results are
identical regardless of worker count — asserted in
`tests/integration/test_pipeline.py`.

Each run records its code revision, working-tree cleanliness, resolved
configuration, condition hash and library versions (`docs/` and the metadata
sidecar beside every result).

## References

See `docs/references.bib`. Primary sources: 3GPP TR 38.901 (channel models),
TS 38.104 (BS radio transmission), TS 38.214 (physical layer procedures),
TR 36.814 (LTE-A evaluation, traffic models).
