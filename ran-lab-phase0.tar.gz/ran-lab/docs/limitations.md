# Limitations

What this simulator does not model, and what that means for its results.

This document exists because the value of a simulation study is bounded by the
honesty of its assumptions. A reader who knows the limitations can judge which
conclusions survive them; a reader who does not will over-trust the numbers.

---

## Current status

**Phase 0.** The experiment harness is complete and tested. The physics is a
placeholder. **No number this repository currently produces is a result.**
Figures generated today demonstrate that the pipeline works end to end; they
say nothing about radio networks. The generated HTML report states this on its
face whenever placeholder components are present in the results.

---

## 1. Placeholder physics (Phase 0 only)

| Component | Current | Effect |
|---|---|---|
| Path loss | fixed exponent n = 3.5 | no LOS/NLOS, frequency or height dependence |
| Shadowing | i.i.d. log-normal | nearby UEs see independent shadowing |
| Fast fading | i.i.d. Rayleigh per slot | **maximal, unrealistic multi-user diversity** |
| Frequency | flat | no frequency-selective scheduling gain |
| PHY | capped Shannon + 3 dB margin | no MCS quantisation, no HARQ |

The fading assumption is the most distorting: fully de-correlated fading gives
channel-aware schedulers the largest possible advantage over Round Robin. The
*ordering* of the policies is still correct, but the *magnitude* of the gap is
not. Resolved in Phase 1.

## 2. Structural limitations (persist beyond Phase 1)

### No handover
Serving cells are assigned once and fixed. Mobility results are valid only
over intervals short relative to cell-crossing time. At 120 km/h a UE crosses
a 200 m UMi cell in ~6 s, so long high-mobility runs model a situation that
could not occur.

### Downlink only
No uplink, no TDD/FDD duplexing, no uplink interference.

### Single-antenna links
No MIMO, beamforming, spatial multiplexing or interference nulling. Since
beamforming is the main interference-management mechanism in real 5G
deployments, absolute SINR is pessimistic and interference-limited conclusions
should be treated as an upper bound on the problem's severity.

### No vertical antenna pattern or downtilt
Horizontal pattern only. Real downtilt suppresses inter-cell interference, so
simulated SINR is pessimistic relative to a tilted deployment.

### Full-power, full-buffer interference
All cells transmit at full power in every slot regardless of their own load.
The standard pessimistic assumption; with bursty traffic real interference is
lower and intermittent.

### One UE per cell per slot
No frequency-domain multi-user scheduling. The interface supports fractional
allocation, but the engine currently grants all PRBs to one UE.

### No control-plane overhead
No signalling, reference-signal overhead, scheduling-request latency or
random-access. Throughput is therefore an over-estimate of what a real system
delivers with the same radio conditions.

### Ideal HARQ feedback
When HARQ arrives in Phase 1, feedback is assumed error-free and immediate.

## 3. Statistical limitations

**Seeds are the unit of replication.** A single run is one draw from a
stochastic process. Every KPI must be reported as a mean over independent
seeds with a confidence interval. `run=multiseed` gives ten; fewer than five
should not be used for any comparison.

**Confidence intervals are on the mean of a KPI, not on the KPI itself.** A
95% interval on mean 5th-percentile throughput does not mean 95% of UEs fall
inside it.

**Significance is not effect size.** With enough seeds any difference becomes
statistically significant. `compare_conditions` reports Cohen's *d* alongside
the p-value for this reason; report both.

**Multiple comparisons are not corrected.** A sweep of 12 conditions tested
pairwise will produce apparently significant differences by chance. Treat
exploratory sweep results as hypothesis-generating.

## 4. Learned-policy caveats (Phase 4)

**Same observation space, or the comparison is void.** If the learned policy
can see anything the baselines cannot, any gain is an artefact. Enforced by a
validation test: a policy trained to imitate PF must match PF within seed
noise.

**Train and test on disjoint seeds.** Otherwise the reported gain measures
memorisation of specific UE drops.

**Beating PF on PF's own objective is the bar.** A policy that raises mean
throughput while lowering 5th-percentile throughput has traded away cell-edge
users, not improved the network. Always report both.

**Generalisation is a separate claim.** A policy trained at one density and
tested at another is doing something harder; state which was done.

## 5. What this simulator is good for

- Comparing resource-management policies **under identical conditions**
- Measuring how a policy's advantage varies with density, load and mobility
- Quantifying throughput/fairness and throughput/energy trade-offs
- Reproducible, provenance-tracked experiment workflows

## 6. What it should not be used for

- Predicting absolute throughput of a real deployment
- Anything requiring MIMO, beamforming or uplink
- Link-level questions (waveform, receiver, coding)
- Capacity planning or regulatory submissions
- Any claim about a real network without calibration against measurements

---

## Reporting standard for this repository

1. Never quote an absolute number without stating the model that produced it.
2. Never report a single-seed result.
3. Always report 5th-percentile alongside mean throughput.
4. Always state which phase's physics produced the number.
5. State this document's relevant limitations when a conclusion depends on one.
