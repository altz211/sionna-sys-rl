# Experiment log

One entry per experiment: the question asked, the configuration that answers
it, and what was found. Entries are appended, never rewritten — a superseded
finding gets a new entry that references the old one, so the record of what
was believed and when survives.

Every entry must cite the **condition hash** and **code revision** of the runs
it describes, both of which appear in the generated report and in every
result row. An entry without them cannot be checked and is worthless.

---

## Template

```markdown
### E<n> — <short title>
**Date** · **Revision** `<git sha>` · **Phase** <n>

**Question.** One sentence. What would change depending on the answer?

**Configuration.**
    ranlab sweep experiment=<name> run=multiseed --workers 8
Conditions: <n> · Seeds: <n> · Condition hashes: `<hash>`, …

**Result.** Numbers with confidence intervals. Figure references.

**Interpretation.** What it means. What it does not mean.

**Caveats.** Which `docs/limitations.md` entries bear on this conclusion.

**Next.** What this makes worth asking.
```

---

## E0 — Harness shakedown

**Date** 2026-09-20 · **Phase** 0

**Question.** Does the pipeline run end to end — compose, simulate, sweep in
parallel, persist with provenance, aggregate over seeds, and render figures
and a report — with no manual step?

**Configuration.**

```bash
ranlab sweep experiment=scheduler_comparison sim=quick \
    scenario.n_ue_per_cell=5 run.n_seeds=3 --workers 3
ranlab report --experiment scheduler_comparison
```

Conditions: 3 (Round Robin, Proportional Fair, Max C/I) · Seeds: 3 · Runs: 9

**Result.** All nine runs completed. Each wrote a schema-validated UE table, a
run table and a provenance sidecar. Aggregation grouped correctly: three
condition hashes, three seeds each. Three figures and the HTML report were
generated from the Parquet tables alone.

Placeholder-physics KPIs, 3 seeds, 10 UEs/cell, 1000 slots:

| Policy | Mean UE (Mbps) | Cell edge p5 (Mbps) | Jain |
|---|---|---|---|
| Round Robin | 2.29 | 0.068 | 0.412 |
| Proportional Fair | 2.68 | 0.166 | 0.453 |
| Max C/I | 5.91 | 0.000 | 0.146 |

**Interpretation.** The harness works. The *ordering* is as expected and is a
property of the policies rather than the channel: Max C/I > PF > RR on
throughput, Max C/I least fair, and Max C/I starves the cell edge completely
(p5 = 0). PF improves both mean and cell-edge throughput over RR.

**These numbers are not results.** They come from the Phase-0 placeholder
channel and PHY (`docs/limitations.md` §1). Fully de-correlated Rayleigh
fading gives channel-aware policies the largest multi-user diversity gain
physically possible, so the *size* of the Max C/I advantage is inflated. The
absolute magnitudes are meaningless until the Phase-1 gates pass.

**Caveats.** `docs/limitations.md` §1 in full; §3 on seed counts — three seeds
is a shakedown, not an experiment.

**Next.** Phase 1: TR 38.901 UMi, EESM abstraction, and validation gates
V1–V4. Re-run E0 afterwards and compare — the ordering must survive, and the
Max C/I gap is expected to narrow substantially.

---

## E1 — <next experiment>

*Pending Phase 1.*
